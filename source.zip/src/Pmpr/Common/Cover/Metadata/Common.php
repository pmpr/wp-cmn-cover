<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb569a3cb08             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Metadata; use Pmpr\Common\Cover\Container; abstract class Common extends Container { const oswseauqqwwuiwcg = "\x6d\x65\164\x61\144\141\x74\141\x5f"; }
