<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f2a2573623             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Metadata; use Pmpr\Common\Cover\Container; abstract class Common extends Container { const oswseauqqwwuiwcg = "\x6d\145\x74\x61\144\141\x74\x61\137"; }
