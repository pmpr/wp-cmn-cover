<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d5a8e62a84             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Metadata; use Pmpr\Common\Cover\Container; abstract class Common extends Container { const oswseauqqwwuiwcg = "\155\x65\x74\x61\x64\141\164\x61\137"; }
