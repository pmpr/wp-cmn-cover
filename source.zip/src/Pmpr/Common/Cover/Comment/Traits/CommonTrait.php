<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d321c131             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment\Traits; use Pmpr\Common\Cover\Comment\Mediator; trait CommonTrait { public function msaiieqagyoqqamc($comment) { $ksaameoqigiaoigg = false; if (!$comment) { goto kaiqsuaywyuckuoo; } $useksmwkuswkwcqg = Mediator::yomcesuuyoqqgycw; $kuowggqsyksiyygi = $this->caokeucsksukesyo()->yagekskwwyqosqcs(); if (!($useksmwkuswkwcqg === $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->gueasuouwqysmomu($kuowggqsyksiyygi->ayueggmoqeeukqmq($comment)))) { goto cqugssuesycomqwa; } $ksaameoqigiaoigg = $kuowggqsyksiyygi->igawqaomowicuayw($useksmwkuswkwcqg, $comment); if ($ksaameoqigiaoigg) { goto ucecweoaoyeoyuue; } $ksaameoqigiaoigg = $this->msaiieqagyoqqamc($kuowggqsyksiyygi->qqiwsumoyiukmgco($comment)); if (!$ksaameoqigiaoigg) { goto eqemcocqsyasqycq; } $this->uwkmaywceaaaigwo()->yagekskwwyqosqcs()->ksmqawcowkmegigw($kuowggqsyksiyygi->iooowgsqoyqseyuu($comment), $useksmwkuswkwcqg, $ksaameoqigiaoigg); eqemcocqsyasqycq: ucecweoaoyeoyuue: cqugssuesycomqwa: kaiqsuaywyuckuoo: return $ksaameoqigiaoigg; } }
