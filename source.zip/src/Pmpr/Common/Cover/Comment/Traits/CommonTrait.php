<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665c231f04cca             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment\Traits; use Pmpr\Common\Cover\Comment\Mediator; trait CommonTrait { public function msaiieqagyoqqamc($comment) { $ksaameoqigiaoigg = false; if (!$comment) { goto ywqakqkmmcoceqka; } $useksmwkuswkwcqg = Mediator::yomcesuuyoqqgycw; $kuowggqsyksiyygi = $this->caokeucsksukesyo()->yagekskwwyqosqcs(); if (!($useksmwkuswkwcqg === $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->gueasuouwqysmomu($kuowggqsyksiyygi->ayueggmoqeeukqmq($comment)))) { goto sooecucuakgkuyis; } $ksaameoqigiaoigg = $kuowggqsyksiyygi->igawqaomowicuayw($useksmwkuswkwcqg, $comment); if ($ksaameoqigiaoigg) { goto qcgyggiaowuqswuw; } $ksaameoqigiaoigg = $this->msaiieqagyoqqamc($kuowggqsyksiyygi->qqiwsumoyiukmgco($comment)); if (!$ksaameoqigiaoigg) { goto yseyyukqaowwouua; } $this->uwkmaywceaaaigwo()->yagekskwwyqosqcs()->ksmqawcowkmegigw($kuowggqsyksiyygi->iooowgsqoyqseyuu($comment), $useksmwkuswkwcqg, $ksaameoqigiaoigg); yseyyukqaowwouua: qcgyggiaowuqswuw: sooecucuakgkuyis: ywqakqkmmcoceqka: return $ksaameoqigiaoigg; } }
