<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d5a8e62a84             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment\Traits; use Pmpr\Common\Cover\Comment\Mediator; trait CommonTrait { public function msaiieqagyoqqamc($comment) { $ksaameoqigiaoigg = false; if (!$comment) { goto quaqmuusokiyqgqe; } $useksmwkuswkwcqg = Mediator::yomcesuuyoqqgycw; $kuowggqsyksiyygi = $this->caokeucsksukesyo()->yagekskwwyqosqcs(); if (!($useksmwkuswkwcqg === $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->gueasuouwqysmomu($kuowggqsyksiyygi->ayueggmoqeeukqmq($comment)))) { goto yuqgwwmqwqiuwmaw; } $ksaameoqigiaoigg = $kuowggqsyksiyygi->igawqaomowicuayw($useksmwkuswkwcqg, $comment); if ($ksaameoqigiaoigg) { goto easqmyamcmeesgya; } $ksaameoqigiaoigg = $this->msaiieqagyoqqamc($kuowggqsyksiyygi->qqiwsumoyiukmgco($comment)); if (!$ksaameoqigiaoigg) { goto qkuiwoqksgayqqmg; } $this->uwkmaywceaaaigwo()->yagekskwwyqosqcs()->ksmqawcowkmegigw($kuowggqsyksiyygi->iooowgsqoyqseyuu($comment), $useksmwkuswkwcqg, $ksaameoqigiaoigg); qkuiwoqksgayqqmg: easqmyamcmeesgya: yuqgwwmqwqiuwmaw: quaqmuusokiyqgqe: return $ksaameoqigiaoigg; } }
