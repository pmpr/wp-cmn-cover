<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d8e73847a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto yqagomygmeoecwey; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto qikaewekoecykeou; yqagomygmeoecwey: Backend::symcgieuakksimmu(); qikaewekoecykeou: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\x69\x74", [$this, "\151\x6e\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\163\137\141\154\154\157\167\137\x72\145\x6e\144\x65\162", [$this, "\165\x69\161\143\x77\163\157\x77\x77\x73\167\x6f\x6d\x6d\153\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
