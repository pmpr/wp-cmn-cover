<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058600f1ef5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto eekaiaeqewiqkkgm; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto kceuusiekagyeoys; eekaiaeqewiqkkgm: Backend::symcgieuakksimmu(); kceuusiekagyeoys: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\x69\164", [$this, "\x69\x6e\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\x73\x5f\141\154\154\x6f\167\137\162\x65\156\144\x65\162", [$this, "\165\x69\161\x63\x77\x73\157\167\167\163\167\157\155\x6d\153\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
