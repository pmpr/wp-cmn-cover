<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6683fecfd1c7e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto mscgewkcqcoowweg; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto suqcsgaosywaauuu; mscgewkcqcoowweg: Backend::symcgieuakksimmu(); suqcsgaosywaauuu: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\151\x74", [$this, "\151\x6e\151\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\163\x5f\141\154\154\157\167\137\162\145\156\x64\145\x72", [$this, "\x75\x69\161\143\167\x73\x6f\x77\x77\163\x77\157\155\155\x6b\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
