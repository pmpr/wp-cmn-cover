<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707b80daa6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto mscgewkcqcoowweg; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto suqcsgaosywaauuu; mscgewkcqcoowweg: Backend::symcgieuakksimmu(); suqcsgaosywaauuu: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\x69\164", [$this, "\151\x6e\x69\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\163\x5f\141\154\154\x6f\167\x5f\162\x65\156\x64\145\162", [$this, "\165\x69\161\x63\x77\163\x6f\x77\x77\x73\x77\x6f\155\155\x6b\141"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
