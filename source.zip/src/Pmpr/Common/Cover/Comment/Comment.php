<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6683fe509cfdc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto mscgewkcqcoowweg; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto suqcsgaosywaauuu; mscgewkcqcoowweg: Backend::symcgieuakksimmu(); suqcsgaosywaauuu: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\151\164", [$this, "\151\156\x69\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\x73\137\141\154\x6c\x6f\167\x5f\x72\145\x6e\144\145\162", [$this, "\x75\x69\x71\143\x77\163\157\167\x77\163\167\x6f\155\155\153\141"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
