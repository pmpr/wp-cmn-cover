<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8e22e6a39             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto uimeeckqksqeekqq; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto iuuuususuuuaieem; uimeeckqksqeekqq: Backend::symcgieuakksimmu(); iuuuususuuuaieem: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\x69\164", [$this, "\151\156\x69\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\x73\137\141\154\x6c\x6f\x77\137\x72\x65\x6e\x64\x65\x72", [$this, "\165\x69\161\x63\x77\x73\x6f\x77\167\x73\x77\157\x6d\x6d\x6b\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
