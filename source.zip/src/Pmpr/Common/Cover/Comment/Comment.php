<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661cfd230d559             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto wusciwkkckmqigms; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto iiiccouaaqsyikae; wusciwkkckmqigms: Backend::symcgieuakksimmu(); iiiccouaaqsyikae: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\x69\x74", [$this, "\x69\156\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\x73\137\x61\154\154\x6f\x77\137\x72\x65\156\x64\145\162", [$this, "\x75\151\x71\143\x77\163\x6f\x77\x77\163\x77\x6f\x6d\x6d\153\141"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
