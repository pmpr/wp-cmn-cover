<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f2a2573623             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto uwaimsisescsgyqk; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto uqcsksaywyqeumig; uwaimsisescsgyqk: Backend::symcgieuakksimmu(); uqcsksaywyqeumig: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\x69\164", [$this, "\151\156\151\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\x73\x5f\x61\x6c\x6c\x6f\x77\137\162\145\156\144\145\x72", [$this, "\x75\151\x71\143\167\x73\x6f\x77\x77\163\167\x6f\155\x6d\x6b\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
