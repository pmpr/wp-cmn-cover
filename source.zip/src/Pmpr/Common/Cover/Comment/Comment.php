<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d321c131             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto wucacaegysmiusai; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto eeomcmuiqwgwwuqk; wucacaegysmiusai: Backend::symcgieuakksimmu(); eeomcmuiqwgwwuqk: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\151\164", [$this, "\x69\x6e\x69\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\163\x5f\141\x6c\x6c\157\167\137\162\x65\x6e\x64\145\x72", [$this, "\165\x69\x71\x63\167\163\x6f\x77\x77\163\x77\x6f\x6d\x6d\153\141"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
