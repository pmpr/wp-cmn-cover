<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb569a3cb08             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto wucacaegysmiusai; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto eeomcmuiqwgwwuqk; wucacaegysmiusai: Backend::symcgieuakksimmu(); eeomcmuiqwgwwuqk: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\x6e\151\164", [$this, "\x69\x6e\x69\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\163\x5f\x61\x6c\x6c\x6f\x77\x5f\x72\145\156\x64\x65\162", [$this, "\165\151\161\143\x77\163\x6f\167\x77\163\167\x6f\x6d\155\153\141"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
