<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf77432f3e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto uimeeckqksqeekqq; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto iuuuususuuuaieem; uimeeckqksqeekqq: Backend::symcgieuakksimmu(); iuuuususuuuaieem: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\x69\x74", [$this, "\x69\x6e\151\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\163\137\141\x6c\x6c\x6f\167\x5f\x72\x65\x6e\x64\145\x72", [$this, "\x75\x69\x71\143\x77\163\157\x77\167\163\x77\157\x6d\x6d\x6b\141"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
