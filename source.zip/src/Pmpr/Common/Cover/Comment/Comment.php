<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634f31ce478f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto uimeeckqksqeekqq; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto iuuuususuuuaieem; uimeeckqksqeekqq: Backend::symcgieuakksimmu(); iuuuususuuuaieem: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\x69\x74", [$this, "\x69\x6e\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\163\x5f\x61\x6c\x6c\157\167\137\x72\145\x6e\x64\x65\x72", [$this, "\165\x69\x71\x63\167\163\x6f\x77\x77\x73\167\x6f\x6d\x6d\153\141"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
