<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce633b36061             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto yqeqouqemksasmqc; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto wgaqkacekoyiwggi; yqeqouqemksasmqc: Backend::symcgieuakksimmu(); wgaqkacekoyiwggi: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\151\164", [$this, "\x69\156\x69\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\x73\x5f\x61\x6c\x6c\157\x77\137\x72\x65\x6e\144\x65\x72", [$this, "\165\x69\x71\143\167\x73\157\x77\x77\163\x77\x6f\155\155\x6b\141"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
