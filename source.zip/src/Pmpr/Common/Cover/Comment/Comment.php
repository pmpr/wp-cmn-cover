<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f0338f6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto qgkiguggkyiycwow; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto becceuuwokgoaewy; qgkiguggkyiycwow: Backend::symcgieuakksimmu(); becceuuwokgoaewy: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\x69\x74", [$this, "\x69\156\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\x73\x5f\x61\x6c\154\x6f\167\137\x72\x65\156\144\x65\162", [$this, "\165\151\161\143\x77\x73\x6f\167\167\x73\x77\157\155\x6d\153\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
