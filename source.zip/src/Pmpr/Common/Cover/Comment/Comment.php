<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1d0fddc76             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto wusciwkkckmqigms; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto iiiccouaaqsyikae; wusciwkkckmqigms: Backend::symcgieuakksimmu(); iiiccouaaqsyikae: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\151\164", [$this, "\x69\x6e\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\163\x5f\x61\x6c\154\157\167\137\162\x65\156\144\145\162", [$this, "\165\x69\x71\143\x77\163\x6f\x77\167\x73\x77\x6f\x6d\155\153\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
