<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661cfe171bf2b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto wusciwkkckmqigms; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto iiiccouaaqsyikae; wusciwkkckmqigms: Backend::symcgieuakksimmu(); iiiccouaaqsyikae: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\151\x74", [$this, "\151\x6e\x69\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\163\x5f\141\154\154\157\167\137\x72\145\x6e\144\x65\x72", [$this, "\165\151\161\143\167\x73\x6f\x77\x77\163\x77\157\155\155\x6b\141"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
