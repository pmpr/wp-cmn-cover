<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6c83ea60             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto qikaewekoecykeou; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto eucqomyqykgoiuge; qikaewekoecykeou: Backend::symcgieuakksimmu(); eucqomyqykgoiuge: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\x69\164", [$this, "\151\x6e\151\164"], 0); } public function init() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto usymasgsyqgsuocg; } Setting::symcgieuakksimmu(); usymasgsyqgsuocg: } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\163\x5f\x61\x6c\154\157\x77\x5f\x72\145\156\144\x65\x72", [$this, "\165\x69\161\x63\x77\x73\157\x77\x77\x73\x77\x6f\155\x6d\x6b\141"]); } }
