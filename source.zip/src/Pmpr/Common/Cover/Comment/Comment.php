<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebd2b1ff7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto eiawsoasmscmqswa; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto ickcmqoiosquugwe; eiawsoasmscmqswa: Backend::symcgieuakksimmu(); ickcmqoiosquugwe: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\151\x74", [$this, "\x69\156\151\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\x73\x5f\141\154\154\157\x77\x5f\x72\145\x6e\144\x65\x72", [$this, "\165\151\161\143\x77\163\x6f\167\167\x73\x77\x6f\155\x6d\x6b\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
