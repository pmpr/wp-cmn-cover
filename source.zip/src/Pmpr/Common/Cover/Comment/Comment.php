<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             667883761741c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto mscgewkcqcoowweg; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto suqcsgaosywaauuu; mscgewkcqcoowweg: Backend::symcgieuakksimmu(); suqcsgaosywaauuu: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\x6e\x69\164", [$this, "\151\156\x69\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\163\x5f\141\154\154\x6f\167\137\162\145\156\x64\145\x72", [$this, "\165\151\161\143\167\163\157\x77\x77\x73\x77\x6f\x6d\x6d\153\141"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
