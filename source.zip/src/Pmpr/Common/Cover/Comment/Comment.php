<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4ba10c294             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto wgaqkacekoyiwggi; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto cscskwugoamcmqyu; wgaqkacekoyiwggi: Backend::symcgieuakksimmu(); cscskwugoamcmqyu: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\151\x74", [$this, "\x69\156\x69\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\x73\x5f\141\154\154\x6f\x77\x5f\x72\x65\x6e\x64\145\162", [$this, "\165\x69\161\143\x77\x73\x6f\x77\167\163\x77\x6f\155\155\153\141"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
