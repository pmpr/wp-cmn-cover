<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66361537dbfa1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto uimeeckqksqeekqq; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto iuuuususuuuaieem; uimeeckqksqeekqq: Backend::symcgieuakksimmu(); iuuuususuuuaieem: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\x69\164", [$this, "\x69\x6e\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\x73\x5f\x61\154\x6c\x6f\x77\x5f\162\145\x6e\144\x65\162", [$this, "\165\151\161\x63\x77\x73\157\x77\x77\163\167\x6f\x6d\x6d\x6b\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
