<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb41cc8f2e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto qikaewekoecykeou; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto eucqomyqykgoiuge; qikaewekoecykeou: Backend::symcgieuakksimmu(); eucqomyqykgoiuge: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\x69\x74", [$this, "\151\156\151\164"], 0); } public function init() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto usymasgsyqgsuocg; } Setting::symcgieuakksimmu(); usymasgsyqgsuocg: } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\x73\x5f\141\x6c\154\x6f\167\137\162\x65\x6e\x64\x65\162", [$this, "\x75\x69\161\143\167\x73\157\167\167\x73\x77\157\x6d\x6d\153\141"]); } }
