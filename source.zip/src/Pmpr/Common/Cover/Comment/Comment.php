<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90935bcac             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto yuimwyoywaiiqacs; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto ocywegekakimmwcq; yuimwyoywaiiqacs: Backend::symcgieuakksimmu(); ocywegekakimmwcq: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\151\164", [$this, "\x69\x6e\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\x73\x5f\x61\x6c\x6c\157\x77\137\x72\x65\156\144\x65\162", [$this, "\165\x69\161\x63\167\x73\x6f\x77\167\163\167\157\155\x6d\153\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
