<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661da07985021             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto wusciwkkckmqigms; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto iiiccouaaqsyikae; wusciwkkckmqigms: Backend::symcgieuakksimmu(); iiiccouaaqsyikae: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\x69\x74", [$this, "\x69\156\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\x73\137\x61\x6c\154\157\167\x5f\x72\x65\x6e\144\145\x72", [$this, "\x75\x69\x71\x63\x77\x73\157\x77\x77\163\167\157\x6d\x6d\x6b\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
