<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668107334b816             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto mscgewkcqcoowweg; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto suqcsgaosywaauuu; mscgewkcqcoowweg: Backend::symcgieuakksimmu(); suqcsgaosywaauuu: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\151\164", [$this, "\151\156\151\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\163\x5f\x61\154\x6c\157\167\x5f\x72\x65\156\144\145\162", [$this, "\x75\151\x71\x63\x77\163\157\167\x77\163\x77\157\155\x6d\153\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
