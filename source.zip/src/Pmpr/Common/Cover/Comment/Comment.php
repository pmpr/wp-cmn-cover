<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6d105d6a3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto uimeeckqksqeekqq; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto iuuuususuuuaieem; uimeeckqksqeekqq: Backend::symcgieuakksimmu(); iuuuususuuuaieem: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\x69\164", [$this, "\x69\156\x69\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\163\137\141\154\154\x6f\167\x5f\162\x65\x6e\x64\x65\162", [$this, "\x75\x69\x71\143\x77\163\157\167\x77\163\167\x6f\x6d\155\x6b\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
