<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edcfcc58f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto kosaqwikueyksqmw; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto gicyayswqyuoekcq; kosaqwikueyksqmw: Backend::symcgieuakksimmu(); gicyayswqyuoekcq: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\x69\x74", [$this, "\x69\x6e\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\163\137\x61\x6c\154\x6f\167\x5f\162\145\156\144\145\x72", [$this, "\165\x69\161\x63\167\x73\x6f\167\x77\x73\167\157\x6d\x6d\153\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
