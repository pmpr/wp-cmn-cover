<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbf0b9b05a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto eekaiaeqewiqkkgm; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto kceuusiekagyeoys; eekaiaeqewiqkkgm: Backend::symcgieuakksimmu(); kceuusiekagyeoys: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\x6e\x69\164", [$this, "\151\156\151\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\x73\137\x61\154\x6c\x6f\x77\x5f\162\x65\x6e\144\x65\x72", [$this, "\165\x69\161\x63\167\163\157\167\x77\163\167\157\155\155\153\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
