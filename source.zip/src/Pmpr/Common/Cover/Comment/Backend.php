<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038baa18e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\x6e\151\164", [$this, "\x69\x6e\151\164"]); } public function init() { if ($this->caokeucsksukesyo()->yagekskwwyqosqcs()->uqwgsuysegkweago() && $this->caokeucsksukesyo()->owicscwgeuqcqaig()->awumyiewiaosiyyy()) { MetaBox::cgygmuguceeosoey("\143\157\155\x6d\145\156\164\x5f\x75\x73\x65\x72\137\151\x64", __("\103\x6f\155\155\x65\x6e\x74\40\x4d\145\164\141\x64\141\x74\x61", PR__CMN__COVER), true)->mkksewyosgeumwsa(MetaBox::ckuwucygcwsiawms(self::wcigqgscaeeqiigq, __("\x55\163\x65\x72", PR__CMN__COVER))->soyqkauogoaqekos())->saemoowcasogykak(IconInterface::wqqgoiyyqicsycmm)->gisikkgygmseekyi(); } } }
