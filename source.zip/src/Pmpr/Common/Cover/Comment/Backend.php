<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edcfcc58f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\151\x74", [$this, "\x69\156\x69\x74"]); } public function init() { if (!($this->caokeucsksukesyo()->yagekskwwyqosqcs()->uqwgsuysegkweago() && $this->caokeucsksukesyo()->owicscwgeuqcqaig()->euqowsuwmgokuqqo())) { goto iikiiioqiyegyaak; } MetaBox::cgygmuguceeosoey("\x63\157\155\x6d\145\156\164\137\x75\x73\x65\x72\137\151\144", __("\x43\x6f\x6d\155\145\156\164\40\115\145\x74\x61\x64\141\x74\141", PR__CMN__COVER), true)->mkksewyosgeumwsa(MetaBox::ckuwucygcwsiawms(self::wcigqgscaeeqiigq, __("\x55\163\145\162", PR__CMN__COVER))->soyqkauogoaqekos())->saemoowcasogykak(IconInterface::wqqgoiyyqicsycmm)->gisikkgygmseekyi(); iikiiioqiyegyaak: } }
