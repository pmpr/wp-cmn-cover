<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6c83ea60             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\151\164", [$this, "\x69\156\151\x74"]); } public function init() { if (!($this->caokeucsksukesyo()->yagekskwwyqosqcs()->uqwgsuysegkweago() && $this->caokeucsksukesyo()->owicscwgeuqcqaig()->euqowsuwmgokuqqo())) { goto oeocukauoyosicso; } MetaBox::cgygmuguceeosoey("\143\x6f\155\155\x65\156\164\x5f\165\x73\145\x72\137\x69\x64", __("\x43\157\155\155\145\x6e\164\40\115\145\164\141\144\x61\x74\x61", PR__CMN__COVER), true)->mkksewyosgeumwsa(MetaBox::ckuwucygcwsiawms(self::wcigqgscaeeqiigq, __("\125\x73\145\162", PR__CMN__COVER))->soyqkauogoaqekos())->saemoowcasogykak(IconInterface::wqqgoiyyqicsycmm)->gisikkgygmseekyi(); oeocukauoyosicso: } }
