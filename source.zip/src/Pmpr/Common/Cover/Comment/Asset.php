<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66361537dbfa1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160", [$this, "\145\x6e\161\x75\145\165\145"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto uqokiksoqcwwqgio; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\157\x6d\155\145\x6e\164", $eygsasmqycagyayw->get("\x63\157\x6d\x6d\x65\156\164\56\x6a\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\x6f\x6d\x6d\145\156\x74", ["\x61\152\x61\170" => Ajax::myikkigscysoykgy]); uqokiksoqcwwqgio: } }
