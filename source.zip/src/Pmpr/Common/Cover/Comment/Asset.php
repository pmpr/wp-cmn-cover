<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f0338f6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\x70", [$this, "\x65\156\161\x75\x65\x75\145"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto emauuoieewwoeyqq; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\157\x6d\x6d\x65\156\x74", $eygsasmqycagyayw->get("\x63\x6f\x6d\155\x65\156\164\56\x6a\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\x6f\x6d\155\x65\156\x74", ["\141\152\x61\x78" => Ajax::myikkigscysoykgy]); emauuoieewwoeyqq: } }
