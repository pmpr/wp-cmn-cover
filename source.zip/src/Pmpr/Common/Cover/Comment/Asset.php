<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661cfd230d559             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\x70", [$this, "\x65\x6e\x71\x75\145\x75\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto ukkcmocamwgiqayu; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\x6f\x6d\155\x65\156\164", $eygsasmqycagyayw->get("\143\157\x6d\155\x65\x6e\x74\x2e\x6a\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\x6f\x6d\155\x65\156\164", ["\x61\x6a\x61\170" => Ajax::myikkigscysoykgy]); ukkcmocamwgiqayu: } }
