<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d321c131             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\160", [$this, "\x65\156\161\x75\x65\165\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto imeaiksowuukikui; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\157\155\x6d\x65\x6e\164", $eygsasmqycagyayw->get("\x63\x6f\x6d\x6d\x65\156\x74\x2e\x6a\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\157\x6d\155\x65\156\164", ["\x61\152\x61\170" => Ajax::myikkigscysoykgy]); imeaiksowuukikui: } }
