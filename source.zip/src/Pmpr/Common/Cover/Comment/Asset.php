<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90935bcac             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\160", [$this, "\145\156\x71\165\145\165\145"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto mggeqkcksyaymcsa; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\157\155\155\145\156\164", $eygsasmqycagyayw->get("\x63\157\x6d\155\x65\156\164\x2e\x6a\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\x6f\155\155\145\156\164", ["\x61\x6a\x61\170" => Ajax::myikkigscysoykgy]); mggeqkcksyaymcsa: } }
