<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6cc684087             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\145\x66\157\x72\x65\137\145\x6e\161\165\x65\x75\x65\137\x66\x72\x6f\156\164\x65\156\x64\137\x61\x73\163\145\164\163", [$this, "\x65\156\x71\165\145\x75\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto ggewkaiwwgkmkwgc; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\x6f\x6d\x6d\145\x6e\164", $eygsasmqycagyayw->get("\143\157\x6d\155\145\156\x74\x2e\152\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\157\x6d\x6d\145\156\164", ["\141\x6a\x61\170" => Ajax::myikkigscysoykgy]); ggewkaiwwgkmkwgc: } }
