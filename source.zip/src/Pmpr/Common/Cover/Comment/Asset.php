<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661da07985021             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\160", [$this, "\145\156\161\x75\145\165\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto ukkcmocamwgiqayu; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\157\x6d\x6d\x65\156\164", $eygsasmqycagyayw->get("\143\157\155\155\x65\x6e\x74\56\x6a\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\157\155\x6d\145\x6e\164", ["\x61\152\x61\x78" => Ajax::myikkigscysoykgy]); ukkcmocamwgiqayu: } }
