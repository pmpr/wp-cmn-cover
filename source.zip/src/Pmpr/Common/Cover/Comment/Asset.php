<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb41cc8f2e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\145\x66\157\x72\145\x5f\145\156\x71\x75\x65\165\145\137\x66\162\x6f\156\164\x65\156\x64\x5f\x61\x73\163\145\x74\163", [$this, "\x65\156\161\165\145\165\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto suqcsgaosywaauuu; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\157\155\x6d\145\156\164", $eygsasmqycagyayw->get("\x63\x6f\155\155\145\x6e\x74\x2e\152\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\x6f\155\x6d\x65\x6e\164", ["\141\x6a\x61\x78" => Ajax::myikkigscysoykgy]); suqcsgaosywaauuu: } }
