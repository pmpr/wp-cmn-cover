<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058600f1ef5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160", [$this, "\x65\156\161\x75\145\x75\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto gsqcoqqsioiyoykq; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\x6f\x6d\x6d\145\156\x74", $eygsasmqycagyayw->get("\x63\x6f\155\155\145\x6e\x74\56\152\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\157\x6d\x6d\145\x6e\164", ["\x61\x6a\x61\x78" => Ajax::myikkigscysoykgy]); gsqcoqqsioiyoykq: } }
