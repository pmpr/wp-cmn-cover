<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6744598eb4de3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\Constants; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\x65\x66\x6f\162\x65\x5f\145\156\161\165\x65\x75\145\137\x66\162\x6f\x6e\164\x65\156\x64\x5f\x61\x73\163\x65\164\163", [$this, "\145\x6e\x71\165\x65\165\145"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->owygwqwawqoiusis($this, "\143\157\x6d\x6d\x65\x6e\x74", "\x63\x6f\x6d\x6d\145\x6e\164\x2e\152\x73")->simswskycwagoeqy())->qkqeooqcomucuwyk($this, "\x63\157\x6d\x6d\145\156\x74", [Constants::wyucqaeuuqkesque => Ajax::myikkigscysoykgy]); } } }
