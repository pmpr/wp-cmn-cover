<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a7eec562             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\145\x66\x6f\x72\145\x5f\145\x6e\x71\x75\x65\x75\x65\x5f\146\x72\x6f\156\x74\x65\156\144\x5f\x61\163\x73\x65\164\x73", [$this, "\145\156\x71\x75\x65\165\x65"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\157\155\155\x65\156\164", $eygsasmqycagyayw->get("\143\157\x6d\x6d\145\156\x74\x2e\x6a\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\157\155\155\145\156\x74", ["\141\x6a\x61\x78" => Ajax::myikkigscysoykgy]); } } }
