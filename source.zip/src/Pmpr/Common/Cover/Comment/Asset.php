<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6d105d6a3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160", [$this, "\x65\x6e\x71\165\x65\165\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto uqokiksoqcwwqgio; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\157\155\x6d\145\x6e\x74", $eygsasmqycagyayw->get("\x63\157\155\155\145\156\164\56\152\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\157\x6d\155\x65\156\164", ["\x61\x6a\141\x78" => Ajax::myikkigscysoykgy]); uqokiksoqcwwqgio: } }
