<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4ba10c294             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\145\x66\x6f\x72\145\137\x65\x6e\161\x75\145\x75\x65\137\146\162\x6f\x6e\x74\x65\x6e\x64\x5f\x61\163\x73\x65\164\163", [$this, "\145\x6e\x71\165\145\x75\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto kkieqqwwascekcmo; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\x6f\x6d\x6d\145\x6e\x74", $eygsasmqycagyayw->get("\x63\x6f\155\x6d\x65\x6e\164\56\x6a\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\157\x6d\x6d\145\x6e\x74", ["\141\152\x61\x78" => Ajax::myikkigscysoykgy]); kkieqqwwascekcmo: } }
