<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edcfcc58f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x70", [$this, "\x65\x6e\x71\165\x65\165\145"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto uiosisocuwokwkie; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\x6f\155\155\145\156\x74", $eygsasmqycagyayw->get("\x63\x6f\155\155\x65\156\164\x2e\152\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\157\x6d\155\145\156\x74", ["\141\x6a\x61\170" => Ajax::myikkigscysoykgy]); uiosisocuwokwkie: } }
