<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce633b36061             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\x66\x6f\162\x65\137\x65\156\x71\165\145\165\x65\137\146\x72\x6f\x6e\164\x65\x6e\x64\x5f\x61\163\163\x65\164\x73", [$this, "\x65\156\x71\x75\145\165\145"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto ggewkaiwwgkmkwgc; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\x6f\155\155\145\x6e\x74", $eygsasmqycagyayw->get("\143\157\155\x6d\x65\156\164\x2e\x6a\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\157\x6d\155\145\x6e\x74", ["\x61\152\x61\x78" => Ajax::myikkigscysoykgy]); ggewkaiwwgkmkwgc: } }
