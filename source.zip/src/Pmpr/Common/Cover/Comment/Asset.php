<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd7abdc00             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\Constants; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\145\x66\x6f\x72\x65\x5f\145\156\161\165\145\165\145\137\146\162\157\156\x74\145\156\144\137\141\163\x73\145\x74\x73", [$this, "\145\156\x71\165\x65\165\145"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->owygwqwawqoiusis($this, "\x63\157\x6d\x6d\145\156\164", "\x63\x6f\155\155\x65\156\164\56\x6a\x73")->simswskycwagoeqy())->qkqeooqcomucuwyk($this, "\x63\x6f\x6d\155\145\156\x74", [Constants::wyucqaeuuqkesque => Ajax::myikkigscysoykgy]); } } }
