<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d444b29914             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\x66\x6f\162\145\137\x65\156\161\x75\145\165\145\137\x66\x72\157\x6e\164\x65\156\144\x5f\141\x73\x73\x65\x74\163", [$this, "\145\x6e\x71\x75\x65\x75\145"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\x6f\x6d\x6d\x65\156\x74", $eygsasmqycagyayw->get("\143\157\x6d\x6d\145\x6e\164\56\152\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\x6f\x6d\x6d\x65\x6e\x74", ["\141\x6a\141\170" => Ajax::myikkigscysoykgy]); } } }
