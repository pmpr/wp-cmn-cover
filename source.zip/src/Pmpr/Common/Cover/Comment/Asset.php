<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85a3b171             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\145\x66\157\162\x65\137\x65\156\161\x75\x65\x75\145\137\x66\x72\157\x6e\x74\145\156\144\x5f\141\163\163\x65\164\x73", [$this, "\145\156\x71\x75\x65\x75\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto mswsoaimesegiiic; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\157\155\155\x65\x6e\x74", $eygsasmqycagyayw->get("\x63\x6f\x6d\x6d\x65\156\164\x2e\152\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\157\155\x6d\x65\x6e\164", ["\141\x6a\141\170" => Ajax::myikkigscysoykgy]); mswsoaimesegiiic: } }
