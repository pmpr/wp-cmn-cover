<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf77432f3e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160", [$this, "\x65\x6e\x71\x75\x65\x75\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto uqokiksoqcwwqgio; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\157\155\x6d\x65\156\164", $eygsasmqycagyayw->get("\143\x6f\x6d\155\x65\156\164\x2e\152\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\x6f\155\x6d\x65\x6e\164", ["\x61\x6a\x61\x78" => Ajax::myikkigscysoykgy]); uqokiksoqcwwqgio: } }
