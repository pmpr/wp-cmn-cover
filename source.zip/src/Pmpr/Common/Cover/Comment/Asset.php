<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6e5e580d3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\x70", [$this, "\145\x6e\161\165\x65\165\145"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto uqokiksoqcwwqgio; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\x6f\x6d\155\x65\156\x74", $eygsasmqycagyayw->get("\x63\x6f\x6d\x6d\x65\156\x74\x2e\x6a\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\157\155\155\x65\x6e\x74", ["\141\152\x61\170" => Ajax::myikkigscysoykgy]); uqokiksoqcwwqgio: } }
