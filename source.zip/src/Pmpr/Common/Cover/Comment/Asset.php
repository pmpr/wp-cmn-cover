<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6b8a7124             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\Constants; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\x65\146\157\x72\145\137\x65\x6e\161\165\145\165\145\x5f\146\162\157\156\164\x65\156\x64\137\x61\163\x73\145\164\163", [$this, "\145\x6e\x71\165\145\x75\x65"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->owygwqwawqoiusis($this, "\x63\x6f\x6d\x6d\145\x6e\x74", "\x63\157\155\155\145\156\164\56\x6a\163")->simswskycwagoeqy())->qkqeooqcomucuwyk($this, "\x63\157\155\x6d\x65\156\164", [Constants::wyucqaeuuqkesque => Ajax::myikkigscysoykgy]); } } }
