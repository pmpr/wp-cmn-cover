<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce113365b6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\145\146\x6f\162\145\x5f\145\x6e\161\165\x65\x75\145\137\x66\x72\157\x6e\x74\x65\156\x64\x5f\141\x73\x73\145\164\x73", [$this, "\145\x6e\x71\165\x65\x75\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto ggewkaiwwgkmkwgc; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\x6f\x6d\155\x65\156\x74", $eygsasmqycagyayw->get("\x63\x6f\x6d\x6d\145\156\x74\x2e\152\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\x6f\155\x6d\x65\156\x74", ["\x61\x6a\141\170" => Ajax::myikkigscysoykgy]); ggewkaiwwgkmkwgc: } }
