<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d88b770bf             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\x66\x6f\x72\x65\137\x65\156\x71\165\x65\x75\x65\x5f\x66\162\157\x6e\164\145\156\144\137\x61\x73\163\x65\x74\163", [$this, "\145\156\x71\x75\145\165\145"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\x6f\x6d\155\145\x6e\x74", $eygsasmqycagyayw->get("\143\157\x6d\155\x65\156\x74\56\152\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\157\x6d\x6d\x65\x6e\x74", ["\x61\152\141\x78" => Ajax::myikkigscysoykgy]); } } }
