<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1d166ebcf             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\160", [$this, "\x65\x6e\161\x75\145\x75\145"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto yseyyukqaowwouua; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\157\x6d\155\x65\156\x74", $eygsasmqycagyayw->get("\143\x6f\155\x6d\145\156\164\x2e\x6a\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\x6f\155\155\x65\x6e\164", ["\141\152\141\x78" => Ajax::myikkigscysoykgy]); yseyyukqaowwouua: } }
