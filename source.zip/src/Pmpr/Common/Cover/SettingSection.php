<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4ba10c294             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Section; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class SettingSection extends Section { public function ikcgmcycisiccyuc() { $this->segment = Constants::ioomakeyqiqowgmk; $this->setting = Setting::symcgieuakksimmu()->youaqkimaoecgsye(); } }
