<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6d105d6a3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Section; abstract class SettingSection extends Section { public function ikcgmcycisiccyuc() { $this->segment = self::ioomakeyqiqowgmk; $this->setting = Setting::symcgieuakksimmu()->youaqkimaoecgsye(); } }
