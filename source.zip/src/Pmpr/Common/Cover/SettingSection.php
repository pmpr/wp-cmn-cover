<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6683fecfd1c7e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Section; abstract class SettingSection extends Section { public function ikcgmcycisiccyuc() { $this->segment = self::ioomakeyqiqowgmk; $this->setting = Setting::symcgieuakksimmu()->youaqkimaoecgsye(); } }
