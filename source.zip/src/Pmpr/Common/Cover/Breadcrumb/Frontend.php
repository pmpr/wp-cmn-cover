<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6cc684087             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\145\156\144\x65\x72", [$this, "\x72\145\x6e\144\x65\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\x65\x74\137\150\x74\155\x6c", [$this, "\x77\x67\161\161\x67\x65\x77\143\155\143\145\x6d\157\145\x77\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto yoagcooekomeokwg; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto yamyagayiooyeekg; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; yamyagayiooyeekg: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\x6e\144\x65\x78", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); yoagcooekomeokwg: return $oqweiggykuywsyas; } }
