<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebd2b1ff7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\x65\156\x64\145\x72", [$this, "\162\x65\x6e\144\x65\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\x65\164\137\150\164\155\154", [$this, "\x77\147\x71\x71\x67\x65\x77\x63\155\x63\145\x6d\x6f\x65\x77\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto uqqaiagaeqgqgaiy; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto uguigkcmukuouway; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; uguigkcmukuouway: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\x6e\144\145\170", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); uqqaiagaeqgqgaiy: return $oqweiggykuywsyas; } }
