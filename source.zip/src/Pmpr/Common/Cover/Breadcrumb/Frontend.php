<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661cfd230d559             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\145\x6e\144\x65\x72", [$this, "\x72\x65\x6e\144\x65\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\x65\x74\137\150\x74\155\154", [$this, "\167\147\x71\x71\x67\x65\167\x63\155\x63\x65\x6d\x6f\x65\167\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto cuwcsamuuqyuyqsu; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto ekoqieigyoeyauqa; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; ekoqieigyoeyauqa: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->sywokgmoskcocqgy($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\x6e\x64\145\x78", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); cuwcsamuuqyuyqsu: return $oqweiggykuywsyas; } }
