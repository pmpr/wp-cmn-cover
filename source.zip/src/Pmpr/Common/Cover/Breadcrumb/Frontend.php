<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edcfcc58f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\145\x6e\144\x65\x72", [$this, "\x72\x65\x6e\x64\x65\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\145\x74\x5f\150\x74\155\x6c", [$this, "\x77\147\161\x71\x67\x65\167\x63\155\x63\x65\155\x6f\145\167\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto acsqgiuageaasiyy; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto mugqyyeayeyggqqk; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; mugqyyeayeyggqqk: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->sywokgmoskcocqgy($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\x6e\x64\145\x78", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); acsqgiuageaasiyy: return $oqweiggykuywsyas; } }
