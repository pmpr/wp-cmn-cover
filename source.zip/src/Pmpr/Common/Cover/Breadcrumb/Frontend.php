<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce113365b6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\145\x6e\x64\x65\x72", [$this, "\x72\x65\156\x64\x65\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\145\164\137\150\x74\155\x6c", [$this, "\167\147\161\161\147\145\167\x63\155\x63\145\155\x6f\x65\x77\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto yoagcooekomeokwg; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto yamyagayiooyeekg; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; yamyagayiooyeekg: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\156\x64\145\x78", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); yoagcooekomeokwg: return $oqweiggykuywsyas; } }
