<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d321c131             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\145\x6e\x64\145\x72", [$this, "\162\x65\156\x64\145\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\x65\x74\137\x68\x74\x6d\x6c", [$this, "\167\x67\161\x71\x67\145\x77\143\x6d\143\145\155\x6f\145\167\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto uougwgeyiokewkkm; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto gygwewcqsmwqismo; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; gygwewcqsmwqismo: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\156\x64\x65\170", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); uougwgeyiokewkkm: return $oqweiggykuywsyas; } }
