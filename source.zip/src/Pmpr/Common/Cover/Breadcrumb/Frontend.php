<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665c231f04cca             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\x65\156\144\145\x72", [$this, "\162\145\156\x64\145\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\x65\164\x5f\x68\x74\155\x6c", [$this, "\167\x67\x71\161\x67\145\167\143\x6d\x63\145\x6d\x6f\145\167\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto giaacoqqqsekcayy; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto syiqkaasoueowwui; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; syiqkaasoueowwui: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->sywokgmoskcocqgy($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\x6e\x64\x65\x78", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); giaacoqqqsekcayy: return $oqweiggykuywsyas; } }
