<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f0338f6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\145\156\144\x65\x72", [$this, "\162\145\156\x64\145\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\145\x74\x5f\x68\x74\x6d\154", [$this, "\167\x67\161\x71\147\x65\167\143\x6d\x63\145\x6d\x6f\x65\167\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto giaacoqqqsekcayy; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto syiqkaasoueowwui; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; syiqkaasoueowwui: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->sywokgmoskcocqgy($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\x6e\x64\145\x78", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); giaacoqqqsekcayy: return $oqweiggykuywsyas; } }
