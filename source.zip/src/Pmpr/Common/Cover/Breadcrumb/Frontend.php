<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed8558a25f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\145\156\x64\x65\162", [$this, "\x72\145\156\x64\145\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\x65\164\137\x68\x74\x6d\154", [$this, "\167\x67\161\x71\147\145\167\x63\155\x63\145\x6d\157\145\167\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if ($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu())) { $ywmkwiwkosakssii = []; if ($mksyucucyswaukig) { $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; } $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\x6e\144\145\170", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); } return $oqweiggykuywsyas; } }
