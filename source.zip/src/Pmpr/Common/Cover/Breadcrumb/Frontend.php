<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fcb2eda4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\145\x6e\144\145\x72", [$this, "\162\145\156\144\145\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\145\164\x5f\150\x74\155\154", [$this, "\167\x67\x71\161\147\145\167\143\155\x63\x65\x6d\157\x65\x77\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if ($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu())) { $ywmkwiwkosakssii = []; if ($mksyucucyswaukig) { $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; } $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\156\144\145\170", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); } return $oqweiggykuywsyas; } }
