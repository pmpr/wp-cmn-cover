<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6c83ea60             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\145\x6e\144\x65\x72", [$this, "\162\145\156\144\x65\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\x65\x74\x5f\x68\x74\155\154", [$this, "\x77\147\x71\x71\147\145\167\143\155\x63\x65\x6d\x6f\x65\x77\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto ssmgmiuqoeiuacsa; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto cqkuuyouqoqyguus; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; cqkuuyouqoqyguus: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\x6e\144\145\x78", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); ssmgmiuqoeiuacsa: return $oqweiggykuywsyas; } }
