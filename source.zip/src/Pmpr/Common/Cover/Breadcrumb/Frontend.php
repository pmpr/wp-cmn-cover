<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4ba10c294             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\145\156\144\x65\162", [$this, "\162\145\156\x64\145\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\x65\x74\x5f\x68\164\x6d\154", [$this, "\167\147\x71\161\147\145\167\x63\x6d\143\145\x6d\157\145\x77\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto eckcqesiokgwkkiw; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto yoagcooekomeokwg; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; yoagcooekomeokwg: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\x6e\x64\x65\x78", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); eckcqesiokgwkkiw: return $oqweiggykuywsyas; } }
