<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbf0b9b05a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\x65\x6e\x64\x65\162", [$this, "\162\x65\x6e\144\145\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\145\164\x5f\x68\x74\x6d\x6c", [$this, "\167\147\161\161\147\x65\x77\x63\x6d\143\x65\155\157\x65\167\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto uqcsksaywyqeumig; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto uwaimsisescsgyqk; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; uwaimsisescsgyqk: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->sywokgmoskcocqgy($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\x6e\144\x65\x78", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); uqcsksaywyqeumig: return $oqweiggykuywsyas; } }
