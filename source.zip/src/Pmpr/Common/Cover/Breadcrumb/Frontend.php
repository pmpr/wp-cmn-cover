<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d8e73847a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\145\156\x64\x65\162", [$this, "\x72\145\x6e\x64\x65\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\145\x74\137\150\x74\x6d\x6c", [$this, "\x77\x67\x71\x71\147\145\x77\143\155\143\145\155\157\145\x77\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto aymmymequcisekie; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto yyamycyesguwueuw; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; yyamycyesguwueuw: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\156\144\x65\x78", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); aymmymequcisekie: return $oqweiggykuywsyas; } }
