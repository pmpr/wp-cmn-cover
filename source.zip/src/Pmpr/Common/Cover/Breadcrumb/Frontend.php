<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8e22e6a39             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\145\x6e\144\145\162", [$this, "\162\145\x6e\x64\x65\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\x65\164\137\x68\164\155\154", [$this, "\x77\147\161\161\x67\145\x77\143\x6d\143\x65\155\x6f\x65\167\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto isgwkwacoyimiauk; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto cscusseysqygsoiy; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; cscusseysqygsoiy: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->sywokgmoskcocqgy($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\156\144\145\x78", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); isgwkwacoyimiauk: return $oqweiggykuywsyas; } }
