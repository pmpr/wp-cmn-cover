<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1d0fddc76             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\145\156\x64\145\x72", [$this, "\x72\145\x6e\x64\145\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\145\x74\137\150\x74\x6d\154", [$this, "\167\x67\x71\161\x67\x65\x77\143\155\x63\145\x6d\157\145\x77\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto cuwcsamuuqyuyqsu; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto ekoqieigyoeyauqa; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; ekoqieigyoeyauqa: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->sywokgmoskcocqgy($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\x6e\x64\x65\170", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); cuwcsamuuqyuyqsu: return $oqweiggykuywsyas; } }
