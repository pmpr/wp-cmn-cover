<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1d166ebcf             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\145\156\x64\x65\162", [$this, "\x72\x65\156\x64\x65\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\145\x74\x5f\150\x74\x6d\154", [$this, "\x77\147\161\161\x67\145\x77\143\155\143\x65\x6d\x6f\x65\x77\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto omqiayeucoioqoao; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto igooksugieceoege; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; igooksugieceoege: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\156\144\x65\170", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); omqiayeucoioqoao: return $oqweiggykuywsyas; } }
