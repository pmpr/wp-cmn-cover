<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a83354743             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\x65\156\x64\145\162", [$this, "\162\x65\156\144\145\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\x65\164\x5f\150\x74\155\x6c", [$this, "\x77\147\x71\x71\147\x65\x77\x63\155\x63\145\x6d\157\x65\167\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if ($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu())) { $ywmkwiwkosakssii = []; if ($mksyucucyswaukig) { $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; } $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\x6e\144\x65\x78", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); } return $oqweiggykuywsyas; } }
