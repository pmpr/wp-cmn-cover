<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6683fe509cfdc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\x65\x6e\x64\145\162", [$this, "\x72\x65\x6e\x64\145\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\x65\x74\x5f\150\x74\155\x6c", [$this, "\x77\x67\161\x71\147\x65\x77\x63\x6d\x63\x65\x6d\157\145\x77\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto aukucaieceiwesmm; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto iauwuugggmegwisk; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; iauwuugggmegwisk: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\x6e\144\x65\x78", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); aukucaieceiwesmm: return $oqweiggykuywsyas; } }
