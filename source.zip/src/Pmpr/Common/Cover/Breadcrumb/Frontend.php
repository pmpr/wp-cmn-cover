<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce633b36061             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\x65\x6e\x64\x65\162", [$this, "\x72\145\156\144\145\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\x65\x74\x5f\150\164\155\154", [$this, "\x77\147\x71\x71\x67\x65\x77\x63\155\143\x65\155\157\145\167\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto yoagcooekomeokwg; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto yamyagayiooyeekg; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; yamyagayiooyeekg: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\x6e\144\145\170", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); yoagcooekomeokwg: return $oqweiggykuywsyas; } }
