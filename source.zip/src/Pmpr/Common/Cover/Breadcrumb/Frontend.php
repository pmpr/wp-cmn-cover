<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668107334b816             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\x65\156\144\x65\x72", [$this, "\x72\145\x6e\x64\145\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\x65\164\x5f\x68\x74\x6d\x6c", [$this, "\167\147\161\161\x67\145\167\x63\155\x63\145\155\157\145\167\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto aukucaieceiwesmm; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto iauwuugggmegwisk; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; iauwuugggmegwisk: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->sywokgmoskcocqgy($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\156\144\145\170", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); aukucaieceiwesmm: return $oqweiggykuywsyas; } }
