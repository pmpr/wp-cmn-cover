<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf77432f3e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\145\x6e\144\145\162", [$this, "\162\x65\156\144\145\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\x65\x74\x5f\x68\164\155\154", [$this, "\167\x67\161\x71\147\x65\167\143\155\x63\145\x6d\157\x65\x77\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto isgwkwacoyimiauk; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto cscusseysqygsoiy; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; cscusseysqygsoiy: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->sywokgmoskcocqgy($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\x6e\144\145\x78", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); isgwkwacoyimiauk: return $oqweiggykuywsyas; } }
