<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d5a8e62a84             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\x65\x6e\x64\x65\162", [$this, "\162\x65\156\144\145\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\x65\x74\x5f\x68\164\155\x6c", [$this, "\x77\147\161\161\147\145\x77\143\155\143\x65\155\157\145\x77\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto isgwkwacoyimiauk; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto cscusseysqygsoiy; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; cscusseysqygsoiy: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->sywokgmoskcocqgy($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\x6e\144\145\x78", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); isgwkwacoyimiauk: return $oqweiggykuywsyas; } }
