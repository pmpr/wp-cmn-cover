<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6d105d6a3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\145\x6e\x64\x65\x72", [$this, "\x72\145\156\144\145\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\x65\164\x5f\150\164\x6d\154", [$this, "\167\x67\x71\161\x67\x65\167\143\155\143\145\155\157\x65\x77\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto isgwkwacoyimiauk; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto cscusseysqygsoiy; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; cscusseysqygsoiy: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->sywokgmoskcocqgy($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\156\144\x65\170", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); isgwkwacoyimiauk: return $oqweiggykuywsyas; } }
