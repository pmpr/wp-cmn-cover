<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058600f1ef5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\145\156\144\145\x72", [$this, "\x72\x65\x6e\x64\x65\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\x65\x74\137\150\x74\x6d\x6c", [$this, "\167\147\x71\x71\x67\x65\167\143\155\x63\x65\x6d\157\x65\x77\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto uqcsksaywyqeumig; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto uwaimsisescsgyqk; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; uwaimsisescsgyqk: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->sywokgmoskcocqgy($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\156\144\145\x78", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); uqcsksaywyqeumig: return $oqweiggykuywsyas; } }
