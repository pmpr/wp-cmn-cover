<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6e5e580d3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\x65\x6e\x64\x65\162", [$this, "\x72\x65\156\144\145\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\x65\x74\137\x68\x74\155\x6c", [$this, "\x77\x67\x71\x71\x67\145\167\x63\155\143\145\x6d\157\x65\167\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto isgwkwacoyimiauk; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto cscusseysqygsoiy; } $ywmkwiwkosakssii[self::ckmqoekmugkggeym] = $mksyucucyswaukig; cscusseysqygsoiy: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->sywokgmoskcocqgy($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\156\144\145\x78", [self::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); isgwkwacoyimiauk: return $oqweiggykuywsyas; } }
