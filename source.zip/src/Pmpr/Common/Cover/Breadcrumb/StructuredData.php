<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634f31ce478f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage\WebPage; use Pmpr\Module\StructuredData\Schema\Intangible\ItemList\BreadcrumbList; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\142\145\x66\157\x72\145\x5f\x72\x65\x6e\144\145\x72\137\x77\145\142\160\x61\x67\145\x5f\x73\x63\150\x65\155\141", [$this, "\x77\x69\x77\151\x6f\x75\x79\145\x67\151\x71\x77\171\x6f\x73\x73"]); } public function wiwiouyegiqwyoss($mooimoaemiymkucu) { if (!($mooimoaemiymkucu instanceof WebPage && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()) && $eaekkwggowaaogiu->uiqcwsowwswommka())) { goto eeyyskqsmquyquqw; } $eaekkwggowaaogiu->create(); if (!($oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi())) { goto cgyakcqgugqgkqiw; } $mooimoaemiymkucu->kmsouiywgsysyogm(new BreadcrumbList($oammesyieqmwuwyi)); cgyakcqgugqgkqiw: eeyyskqsmquyquqw: return $mooimoaemiymkucu; } }
