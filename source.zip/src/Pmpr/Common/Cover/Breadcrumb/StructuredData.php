<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d45f99e4b5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage\WebPage; use Pmpr\Module\StructuredData\Schema\Intangible\ItemList\BreadcrumbList; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\x62\145\x66\x6f\162\x65\x5f\x72\x65\156\x64\x65\162\x5f\167\145\142\160\141\x67\x65\x5f\163\x63\150\x65\x6d\141", [$this, "\x77\x69\167\151\x6f\x75\x79\x65\147\151\161\x77\x79\x6f\163\x73"]); } public function wiwiouyegiqwyoss($mooimoaemiymkucu) { if (!($mooimoaemiymkucu instanceof WebPage && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()) && $eaekkwggowaaogiu->uiqcwsowwswommka())) { goto eeyyskqsmquyquqw; } $eaekkwggowaaogiu->create(); if (!($oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi())) { goto cgyakcqgugqgkqiw; } $mooimoaemiymkucu->kmsouiywgsysyogm(new BreadcrumbList($oammesyieqmwuwyi)); cgyakcqgugqgkqiw: eeyyskqsmquyquqw: return $mooimoaemiymkucu; } }
