<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f0338f6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage\WebPage; use Pmpr\Module\StructuredData\Schema\Intangible\ItemList\BreadcrumbList; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\x62\x65\146\157\162\x65\x5f\x72\145\x6e\144\145\x72\x5f\x77\x65\142\x70\x61\147\145\137\163\x63\150\145\155\x61", [$this, "\167\151\x77\x69\x6f\x75\x79\x65\x67\151\x71\167\171\157\163\x73"]); } public function wiwiouyegiqwyoss($mooimoaemiymkucu) { if (!($mooimoaemiymkucu instanceof WebPage && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()) && $eaekkwggowaaogiu->uiqcwsowwswommka())) { goto gkyawqqcmigqgaiq; } $eaekkwggowaaogiu->create(); if (!($oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi())) { goto wmywuusgukmmaams; } $mooimoaemiymkucu->kmsouiywgsysyogm(new BreadcrumbList($oammesyieqmwuwyi)); wmywuusgukmmaams: gkyawqqcmigqgaiq: return $mooimoaemiymkucu; } }
