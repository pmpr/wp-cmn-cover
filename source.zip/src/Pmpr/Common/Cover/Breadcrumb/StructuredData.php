<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             667883761741c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage\WebPage; use Pmpr\Module\StructuredData\Schema\Intangible\ItemList\BreadcrumbList; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\142\x65\146\157\x72\x65\137\x72\x65\156\144\145\162\137\167\145\x62\x70\141\x67\x65\x5f\x73\143\x68\145\x6d\x61", [$this, "\x77\151\x77\x69\x6f\x75\x79\145\x67\x69\161\167\x79\157\x73\163"]); } public function wiwiouyegiqwyoss($mooimoaemiymkucu) { if (!($mooimoaemiymkucu instanceof WebPage && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()) && $eaekkwggowaaogiu->uiqcwsowwswommka())) { goto iqsgossweywksoia; } $eaekkwggowaaogiu->create(); if (!($oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi())) { goto igwkcikeyoowosoi; } $mooimoaemiymkucu->kmsouiywgsysyogm(new BreadcrumbList($oammesyieqmwuwyi)); igwkcikeyoowosoi: iqsgossweywksoia: return $mooimoaemiymkucu; } }
