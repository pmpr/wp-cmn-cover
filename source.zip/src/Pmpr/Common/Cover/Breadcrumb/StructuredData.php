<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6cc684087             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage\WebPage; use Pmpr\Module\StructuredData\Schema\Intangible\ItemList\BreadcrumbList; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\142\x65\146\157\162\145\137\x72\x65\156\x64\x65\x72\x5f\167\x65\x62\160\141\x67\145\x5f\163\x63\150\x65\x6d\141", [$this, "\167\x69\x77\x69\157\165\x79\145\147\151\161\167\171\x6f\163\x73"]); } public function wiwiouyegiqwyoss($mooimoaemiymkucu) { if (!($mooimoaemiymkucu instanceof WebPage && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()) && $eaekkwggowaaogiu->uiqcwsowwswommka())) { goto yiceawuuiusakwiq; } $eaekkwggowaaogiu->create(); if (!($oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi())) { goto qeuyekusasqmcqms; } $mooimoaemiymkucu->kmsouiywgsysyogm(new BreadcrumbList($oammesyieqmwuwyi)); qeuyekusasqmcqms: yiceawuuiusakwiq: return $mooimoaemiymkucu; } }
