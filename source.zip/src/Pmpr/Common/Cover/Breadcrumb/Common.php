<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6c83ea60             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\Container; use Pmpr\Common\Cover\Setting\Setting as BaseSetting; abstract class Common extends Container { const iukiayaokaiiicwo = "\142\162\x65\141\144\x63\x72\x75\155\142\137"; const ggcmgaccygaquiwu = self::iukiayaokaiiicwo . "\x62\145\x66\157\x72\145\x5f\143\x72\145\x61\x74\145\x5f"; public function uiqcwsowwswommka($post = null) : bool { $cuakwceieagskoaa = false; if (!BaseSetting::eiwcuqigayigimak(Setting::mgimioakqsosoqcc)) { goto gwoacimkeyymqccq; } $cuakwceieagskoaa = true; if (!($post = (string) $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->iooowgsqoyqseyuu($post))) { goto wiqigqgiegmacgsw; } $couiucmsqaieciue = BaseSetting::eiwcuqigayigimak(Setting::gsqueoqmwgwgykuy, []); $cuakwceieagskoaa = !in_array($post, $couiucmsqaieciue, true); wiqigqgiegmacgsw: $cuakwceieagskoaa = $this->ocksiywmkyaqseou(self::iukiayaokaiiicwo . "\141\x6c\154\157\167\x5f\x72\145\156\x64\x65\162", $cuakwceieagskoaa, $post); gwoacimkeyymqccq: return $cuakwceieagskoaa; } }
