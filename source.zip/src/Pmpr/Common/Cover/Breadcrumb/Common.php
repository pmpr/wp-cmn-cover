<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb41cc8f2e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\Container; use Pmpr\Common\Cover\Setting\Setting as BaseSetting; abstract class Common extends Container { const iukiayaokaiiicwo = "\x62\x72\x65\x61\x64\x63\x72\165\155\142\x5f"; const ggcmgaccygaquiwu = self::iukiayaokaiiicwo . "\142\145\x66\157\162\145\137\143\162\x65\141\x74\x65\x5f"; public function uiqcwsowwswommka($post = null) : bool { $cuakwceieagskoaa = false; if (!BaseSetting::eiwcuqigayigimak(Setting::mgimioakqsosoqcc)) { goto ueaiskyiqcquiika; } $cuakwceieagskoaa = true; if (!($post = (string) $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->iooowgsqoyqseyuu($post))) { goto koggssokukoukkay; } $couiucmsqaieciue = BaseSetting::eiwcuqigayigimak(Setting::gsqueoqmwgwgykuy, []); $cuakwceieagskoaa = !in_array($post, $couiucmsqaieciue, true); koggssokukoukkay: $cuakwceieagskoaa = $this->ocksiywmkyaqseou(self::iukiayaokaiiicwo . "\141\154\x6c\157\x77\137\162\x65\x6e\144\145\162", $cuakwceieagskoaa, $post); ueaiskyiqcquiika: return $cuakwceieagskoaa; } }
