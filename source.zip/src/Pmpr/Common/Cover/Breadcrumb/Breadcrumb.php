<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6d105d6a3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Breadcrumb extends Common { public function mameiwsayuyquoeq() { Frontend::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\x6e\151\164", [$this, "\151\x6e\x69\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\145\164\x5f\x69\x74\145\x6d\x73", [$this, "\x77\141\x73\147\167\163\x6f\x67\155\165\161\165\161\x65\x61\141"], 10, 2); } public function init() { SettingSection::symcgieuakksimmu(); } public function aqyikqugcomoqqqi() { if (!$this->omseesogaocascyo("\x73\164\162\x75\143\164\165\162\145\144\x2d\x64\141\x74\x61")) { goto mkwkkmkgiqiamacc; } StructuredData::symcgieuakksimmu(); mkwkkmkgiqiamacc: } public function wasgwsogmuquqeaa(array $oammesyieqmwuwyi = [], array $ywmkwiwkosakssii = []) : array { if (!($this->uiqcwsowwswommka() && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto uaqackioaiqwcocy; } $eaekkwggowaaogiu->create($ywmkwiwkosakssii); $oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi(); uaqackioaiqwcocy: return $oammesyieqmwuwyi; } }
