<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d88b770bf             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Breadcrumb extends Common { public function mameiwsayuyquoeq() { Frontend::symcgieuakksimmu(); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\145\164\x5f\151\x74\x65\155\163", [$this, "\167\141\163\x67\167\163\157\147\155\x75\161\165\x71\x65\141\x61"], 10, 2); } public function aqyikqugcomoqqqi() { if ($this->caokeucsksukesyo()->cqusmgskowmesgcg()->iqqgmieeqemiowuk("\x73\x74\x72\165\143\164\x75\162\x65\x64\55\144\x61\164\141")) { StructuredData::symcgieuakksimmu(); } } public function wasgwsogmuquqeaa(array $oammesyieqmwuwyi = [], array $ywmkwiwkosakssii = []) : array { if ($this->uiqcwsowwswommka() && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu())) { $eaekkwggowaaogiu->create($ywmkwiwkosakssii); $oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi(); } return $oammesyieqmwuwyi; } }
