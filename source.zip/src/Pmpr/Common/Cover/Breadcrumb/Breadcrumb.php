<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd7abdc00             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Breadcrumb extends Common { public function mameiwsayuyquoeq() { Frontend::symcgieuakksimmu(); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\145\164\137\151\x74\x65\155\163", [$this, "\167\141\163\x67\167\x73\157\147\x6d\165\161\x75\161\145\141\141"], 10, 2); } public function aqyikqugcomoqqqi() { if ($this->caokeucsksukesyo()->cqusmgskowmesgcg()->iqqgmieeqemiowuk("\163\x74\162\165\x63\164\165\x72\x65\144\55\x64\x61\x74\141")) { StructuredData::symcgieuakksimmu(); } } public function wasgwsogmuquqeaa(array $oammesyieqmwuwyi = [], array $ywmkwiwkosakssii = []) : array { if ($this->uiqcwsowwswommka() && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu())) { $eaekkwggowaaogiu->create($ywmkwiwkosakssii); $oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi(); } return $oammesyieqmwuwyi; } }
