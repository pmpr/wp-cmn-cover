<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707b80daa6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Breadcrumb extends Common { public function mameiwsayuyquoeq() { Frontend::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\x69\x74", [$this, "\151\156\x69\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\x65\164\137\151\x74\145\155\x73", [$this, "\167\141\x73\147\x77\163\157\147\x6d\165\161\165\x71\x65\141\141"], 10, 2); } public function init() { SettingSection::symcgieuakksimmu(); } public function aqyikqugcomoqqqi() { if (!$this->omseesogaocascyo("\x73\x74\162\165\143\x74\x75\162\x65\144\55\x64\x61\164\x61")) { goto awaqksikyomsuaeo; } StructuredData::symcgieuakksimmu(); awaqksikyomsuaeo: } public function wasgwsogmuquqeaa(array $oammesyieqmwuwyi = [], array $ywmkwiwkosakssii = []) : array { if (!($this->uiqcwsowwswommka() && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto cuommomwmsackoqc; } $eaekkwggowaaogiu->create($ywmkwiwkosakssii); $oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi(); cuommomwmsackoqc: return $oammesyieqmwuwyi; } }
