<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f0338f6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Breadcrumb extends Common { public function mameiwsayuyquoeq() { Frontend::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\151\164", [$this, "\x69\x6e\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\145\x74\x5f\151\164\x65\155\163", [$this, "\167\x61\163\x67\x77\163\x6f\147\x6d\x75\161\x75\x71\x65\141\x61"], 10, 2); } public function init() { SettingSection::symcgieuakksimmu(); } public function aqyikqugcomoqqqi() { if (!$this->omseesogaocascyo("\163\x74\162\165\143\x74\x75\162\x65\144\x2d\144\x61\x74\x61")) { goto ewymsmkkiksgwysk; } StructuredData::symcgieuakksimmu(); ewymsmkkiksgwysk: } public function wasgwsogmuquqeaa(array $oammesyieqmwuwyi = [], array $ywmkwiwkosakssii = []) : array { if (!($this->uiqcwsowwswommka() && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto cmegwsegsosyqcai; } $eaekkwggowaaogiu->create($ywmkwiwkosakssii); $oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi(); cmegwsegsosyqcai: return $oammesyieqmwuwyi; } }
