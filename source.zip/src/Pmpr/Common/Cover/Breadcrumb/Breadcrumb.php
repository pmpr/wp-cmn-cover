<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d5a8e62a84             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Breadcrumb extends Common { public function mameiwsayuyquoeq() { Frontend::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\151\x74", [$this, "\151\156\x69\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\145\x74\137\151\x74\145\155\163", [$this, "\x77\x61\x73\147\x77\163\157\x67\x6d\x75\x71\165\x71\145\x61\x61"], 10, 2); } public function init() { SettingSection::symcgieuakksimmu(); } public function aqyikqugcomoqqqi() { if (!$this->omseesogaocascyo("\x73\x74\162\165\x63\x74\x75\x72\145\x64\55\144\141\x74\x61")) { goto mkwkkmkgiqiamacc; } StructuredData::symcgieuakksimmu(); mkwkkmkgiqiamacc: } public function wasgwsogmuquqeaa(array $oammesyieqmwuwyi = [], array $ywmkwiwkosakssii = []) : array { if (!($this->uiqcwsowwswommka() && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto uaqackioaiqwcocy; } $eaekkwggowaaogiu->create($ywmkwiwkosakssii); $oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi(); uaqackioaiqwcocy: return $oammesyieqmwuwyi; } }
