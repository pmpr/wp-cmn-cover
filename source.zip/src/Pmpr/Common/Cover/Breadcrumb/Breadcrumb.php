<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661cfe171bf2b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Breadcrumb extends Common { public function mameiwsayuyquoeq() { Frontend::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\x6e\x69\x74", [$this, "\151\x6e\151\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\x65\164\x5f\x69\x74\x65\155\163", [$this, "\x77\x61\x73\147\167\x73\157\x67\x6d\x75\x71\x75\161\145\141\141"], 10, 2); } public function init() { SettingSection::symcgieuakksimmu(); } public function aqyikqugcomoqqqi() { if (!$this->omseesogaocascyo("\163\164\x72\x75\x63\164\x75\162\145\x64\55\x64\x61\x74\x61")) { goto ssagcgqaucssyego; } StructuredData::symcgieuakksimmu(); ssagcgqaucssyego: } public function wasgwsogmuquqeaa(array $oammesyieqmwuwyi = [], array $ywmkwiwkosakssii = []) : array { if (!($this->uiqcwsowwswommka() && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto mqgeseysuwcaqwiy; } $eaekkwggowaaogiu->create($ywmkwiwkosakssii); $oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi(); mqgeseysuwcaqwiy: return $oammesyieqmwuwyi; } }
