<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edcfcc58f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\SettingSection as BaseClass; use Pmpr\Common\Foundation\Interfaces\IconInterface; class SettingSection extends BaseClass { const iukiayaokaiiicwo = "\x62\162\x65\x61\x64\143\162\x75\x6d\x62\x5f"; const mgimioakqsosoqcc = self::iukiayaokaiiicwo . self::iccwcygaeqmomooo; const gsqueoqmwgwgykuy = self::iukiayaokaiiicwo . self::qgiwmgmeaagqwgkw; public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\142\x72\x65\x61\x64\143\162\165\155\x62")->gswweykyogmsyawy(__("\x42\x72\x65\x61\144\143\162\x75\x6d\x62", PR__CMN__COVER))->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::mgimioakqsosoqcc)->gswweykyogmsyawy(__("\x44\x69\163\160\154\x61\x79\x20\x42\x72\x65\141\144\x63\162\165\x6d\x62", PR__CMN__COVER)))->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::gsqueoqmwgwgykuy)->gswweykyogmsyawy(__("\x45\x78\x63\x6c\x75\144\x65\x20\x50\157\163\x74\x73", PR__CMN__COVER))->ukqywcsoogkyoaoa()->oikgogcweiiaocka()->mkmssscwmeekwgqo())->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->jyumyyugiwwiqomk(100)); } }
