<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661da07985021             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\SettingSection as BaseClass; use Pmpr\Common\Foundation\Interfaces\IconInterface; class SettingSection extends BaseClass { const iukiayaokaiiicwo = "\x62\x72\145\x61\x64\143\x72\165\x6d\x62\x5f"; const mgimioakqsosoqcc = self::iukiayaokaiiicwo . self::iccwcygaeqmomooo; const gsqueoqmwgwgykuy = self::iukiayaokaiiicwo . self::qgiwmgmeaagqwgkw; public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\142\162\x65\x61\x64\143\x72\x75\x6d\x62")->gswweykyogmsyawy(__("\x42\x72\145\141\144\143\x72\x75\155\142", PR__CMN__COVER))->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::mgimioakqsosoqcc)->gswweykyogmsyawy(__("\104\x69\x73\x70\154\141\x79\40\102\162\145\x61\x64\x63\x72\x75\155\142", PR__CMN__COVER)))->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::gsqueoqmwgwgykuy)->gswweykyogmsyawy(__("\x45\x78\143\x6c\165\x64\x65\x20\120\157\x73\x74\x73", PR__CMN__COVER))->ukqywcsoogkyoaoa()->oikgogcweiiaocka()->mkmssscwmeekwgqo())->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->jyumyyugiwwiqomk(100)); } }
