<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66361537dbfa1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\SettingSection as BaseClass; use Pmpr\Common\Foundation\Interfaces\IconInterface; class SettingSection extends BaseClass { const iukiayaokaiiicwo = "\x62\x72\x65\x61\144\x63\x72\165\x6d\x62\x5f"; const mgimioakqsosoqcc = self::iukiayaokaiiicwo . self::iccwcygaeqmomooo; const gsqueoqmwgwgykuy = self::iukiayaokaiiicwo . self::qgiwmgmeaagqwgkw; public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x62\x72\x65\141\144\143\162\165\x6d\142")->gswweykyogmsyawy(__("\x42\162\x65\x61\144\x63\162\x75\155\142", PR__CMN__COVER))->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::mgimioakqsosoqcc)->gswweykyogmsyawy(__("\x44\x69\x73\x70\x6c\141\x79\40\102\162\145\141\144\143\x72\x75\x6d\142", PR__CMN__COVER)))->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::gsqueoqmwgwgykuy)->gswweykyogmsyawy(__("\105\x78\x63\154\165\x64\x65\40\120\157\x73\x74\163", PR__CMN__COVER))->ukqywcsoogkyoaoa()->oikgogcweiiaocka()->mkmssscwmeekwgqo())->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->jyumyyugiwwiqomk(100)); } }
