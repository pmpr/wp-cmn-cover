<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668107334b816             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\SettingSection as BaseClass; use Pmpr\Common\Foundation\Interfaces\IconInterface; class SettingSection extends BaseClass { const iukiayaokaiiicwo = "\142\x72\145\141\144\x63\162\165\155\x62\x5f"; const mgimioakqsosoqcc = self::iukiayaokaiiicwo . self::iccwcygaeqmomooo; const gsqueoqmwgwgykuy = self::iukiayaokaiiicwo . self::qgiwmgmeaagqwgkw; public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\142\x72\x65\141\144\x63\162\165\x6d\x62")->gswweykyogmsyawy(__("\x42\x72\x65\x61\144\143\x72\x75\155\x62", PR__CMN__COVER))->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::mgimioakqsosoqcc)->gswweykyogmsyawy(__("\104\151\x73\160\154\x61\171\40\x42\x72\145\x61\x64\x63\x72\x75\x6d\x62", PR__CMN__COVER)))->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::gsqueoqmwgwgykuy)->gswweykyogmsyawy(__("\x45\170\x63\x6c\x75\x64\145\x20\x50\157\x73\164\163", PR__CMN__COVER))->ukqywcsoogkyoaoa()->oikgogcweiiaocka()->mkmssscwmeekwgqo())->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->jyumyyugiwwiqomk(100)); } }
