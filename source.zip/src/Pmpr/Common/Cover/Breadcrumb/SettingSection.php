<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbf0b9b05a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\SettingSection as BaseClass; use Pmpr\Common\Foundation\Interfaces\IconInterface; class SettingSection extends BaseClass { const iukiayaokaiiicwo = "\142\162\145\x61\x64\x63\162\165\x6d\x62\x5f"; const mgimioakqsosoqcc = self::iukiayaokaiiicwo . self::iccwcygaeqmomooo; const gsqueoqmwgwgykuy = self::iukiayaokaiiicwo . self::qgiwmgmeaagqwgkw; public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\142\x72\145\x61\144\x63\x72\x75\155\x62")->gswweykyogmsyawy(__("\102\162\145\141\x64\143\162\x75\x6d\142", PR__CMN__COVER))->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::mgimioakqsosoqcc)->gswweykyogmsyawy(__("\x44\151\x73\x70\154\141\x79\40\102\162\145\x61\144\x63\162\x75\155\142", PR__CMN__COVER)))->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::gsqueoqmwgwgykuy)->gswweykyogmsyawy(__("\x45\170\143\154\x75\x64\145\x20\x50\x6f\163\x74\x73", PR__CMN__COVER))->ukqywcsoogkyoaoa()->oikgogcweiiaocka()->mkmssscwmeekwgqo())->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->jyumyyugiwwiqomk(100)); } }
