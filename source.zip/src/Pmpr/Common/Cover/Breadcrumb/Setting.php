<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038baa18e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\Setting\Section; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Setting extends Section { const iukiayaokaiiicwo = "\x62\162\x65\141\x64\x63\x72\x75\155\142\x5f"; const mgimioakqsosoqcc = self::iukiayaokaiiicwo . Constants::iccwcygaeqmomooo; const gsqueoqmwgwgykuy = self::iukiayaokaiiicwo . Constants::qgiwmgmeaagqwgkw; public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\142\x72\x65\x61\144\143\x72\x75\x6d\142")->gswweykyogmsyawy(__("\x42\162\x65\141\x64\143\162\165\155\x62", PR__CMN__COVER))->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::mgimioakqsosoqcc)->gswweykyogmsyawy(__("\x44\151\163\160\154\141\x79\x20\102\x72\145\x61\144\143\162\165\x6d\142", PR__CMN__COVER)))->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::gsqueoqmwgwgykuy)->gswweykyogmsyawy(__("\x45\170\x63\154\x75\x64\145\40\x50\157\x73\164\163", PR__CMN__COVER))->ukqywcsoogkyoaoa()->oikgogcweiiaocka()->mkmssscwmeekwgqo())->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->jyumyyugiwwiqomk(100)); } }
