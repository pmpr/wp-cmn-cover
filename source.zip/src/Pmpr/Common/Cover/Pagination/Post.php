<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf77432f3e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Pagination; class Post extends Common { protected ?string $type = self::mswoacegomcucaik; public function kooycocagkkmaiay($ywmkwiwkosakssii = []) { return paginate_links($ywmkwiwkosakssii); } }
