<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8e22e6a39             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Pagination; class Comment extends Common { protected ?string $type = self::COMMENT; public function kooycocagkkmaiay($ywmkwiwkosakssii = []) { return $this->caokeucsksukesyo()->yagekskwwyqosqcs()->kocmoimugqqoeawy($ywmkwiwkosakssii); } }
