<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4ba10c294             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\160\x6c\141\x74\145\x5f\162\145\x64\151\162\145\x63\x74", [$this, "\163\165\x79\141\167\171\x63\x69\165\145\143\145\x67\x67\x61\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto qccmuwiwykuegoga; } ob_start([$this, "\171\x75\141\145\161\x6d\x6d\145\x6f\x67\157\167\157\141\x65\155"]); qccmuwiwykuegoga: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\x74\x69\155\151\172\141\x74\151\x6f\x6e\x5f\x62\x75\x66\x66\x65\x72", $nsmgceoqaqogqmuw); } }
