<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a83354743             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\x6d\x70\154\141\x74\145\x5f\162\x65\144\x69\x72\x65\143\164", [$this, "\163\165\171\x61\x77\x79\x63\x69\x75\x65\x63\x65\x67\147\x61\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\141\145\161\x6d\155\x65\157\147\157\167\x6f\141\x65\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\164\x69\155\x69\x7a\x61\x74\151\x6f\156\x5f\142\x75\x66\146\145\162", $nsmgceoqaqogqmuw); } }
