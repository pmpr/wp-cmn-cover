<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678030c3dd532             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\155\160\x6c\141\164\x65\137\162\145\x64\151\162\145\143\x74", [$this, "\163\x75\x79\x61\x77\x79\x63\151\x75\x65\143\145\x67\x67\x61\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\x61\x65\x71\x6d\155\145\x6f\147\157\x77\x6f\x61\x65\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\x69\155\151\172\141\164\151\x6f\156\x5f\142\x75\146\x66\145\162", $nsmgceoqaqogqmuw); } }
