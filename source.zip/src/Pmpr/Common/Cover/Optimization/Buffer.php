<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90935bcac             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\x6d\x70\154\141\164\145\x5f\162\x65\x64\151\162\x65\x63\164", [$this, "\163\x75\x79\x61\x77\x79\143\151\165\x65\143\145\x67\x67\141\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto auumaoycmsmsgigs; } ob_start([$this, "\171\x75\x61\145\161\155\155\x65\157\x67\x6f\167\x6f\x61\x65\x6d"]); auumaoycmsmsgigs: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\x69\155\x69\172\x61\x74\151\157\x6e\x5f\142\x75\146\146\x65\162", $nsmgceoqaqogqmuw); } }
