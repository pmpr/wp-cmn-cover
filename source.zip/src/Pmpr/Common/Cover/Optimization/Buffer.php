<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6744598eb4de3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\155\160\x6c\141\164\145\137\162\145\x64\x69\x72\x65\x63\x74", [$this, "\163\165\x79\141\167\x79\143\151\x75\x65\143\145\x67\x67\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\x75\x61\145\x71\x6d\155\x65\157\x67\157\x77\157\141\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\x74\151\x6d\151\x7a\141\164\151\x6f\x6e\x5f\x62\x75\x66\146\145\x72", $nsmgceoqaqogqmuw); } }
