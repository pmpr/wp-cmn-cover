<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fcb2eda4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\x6d\x70\x6c\x61\164\x65\x5f\162\145\144\x69\x72\x65\143\x74", [$this, "\163\165\171\x61\x77\x79\143\x69\165\145\143\x65\147\147\141\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\165\x61\145\x71\x6d\x6d\145\157\x67\157\x77\x6f\141\x65\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\151\x6d\151\172\x61\164\151\x6f\156\137\x62\165\146\x66\x65\x72", $nsmgceoqaqogqmuw); } }
