<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a7eec562             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\160\154\141\x74\x65\x5f\x72\145\144\x69\162\x65\x63\x74", [$this, "\x73\165\171\141\167\x79\x63\x69\x75\x65\143\145\147\147\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\x75\141\x65\x71\155\x6d\145\157\147\157\167\157\141\145\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\x74\151\155\x69\x7a\x61\x74\151\157\156\137\142\165\146\146\x65\x72", $nsmgceoqaqogqmuw); } }
