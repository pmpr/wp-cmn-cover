<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637dd936a824             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\155\160\154\141\x74\145\x5f\x72\145\x64\151\162\145\x63\x74", [$this, "\163\165\x79\x61\x77\x79\143\151\x75\x65\143\x65\x67\147\141\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto uaicwcqwauosmsqm; } ob_start([$this, "\x79\x75\x61\x65\x71\155\x6d\x65\x6f\x67\x6f\167\x6f\141\145\155"]); uaicwcqwauosmsqm: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\x74\151\x6d\x69\x7a\x61\x74\151\x6f\156\x5f\x62\165\146\146\145\x72", $nsmgceoqaqogqmuw); } }
