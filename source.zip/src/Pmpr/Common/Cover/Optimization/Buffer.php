<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1d166ebcf             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\155\x70\154\141\164\x65\137\162\145\144\151\x72\x65\x63\x74", [$this, "\163\x75\x79\141\x77\x79\x63\151\165\145\143\145\147\x67\141\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto eequksumcoogyoem; } ob_start([$this, "\171\165\141\145\x71\155\x6d\145\x6f\x67\x6f\167\x6f\141\x65\155"]); eequksumcoogyoem: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\151\155\151\x7a\x61\164\x69\x6f\156\137\x62\165\x66\146\x65\x72", $nsmgceoqaqogqmuw); } }
