<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85a3b171             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\155\x70\154\141\164\x65\137\162\x65\144\151\162\145\143\164", [$this, "\x73\165\x79\x61\x77\171\143\x69\165\x65\143\x65\x67\147\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto gkqiqaqecmoogmaa; } ob_start([$this, "\x79\165\x61\x65\x71\x6d\155\145\x6f\147\157\x77\157\x61\145\155"]); gkqiqaqecmoogmaa: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\x69\x6d\x69\172\x61\x74\x69\x6f\x6e\x5f\x62\165\x66\x66\x65\162", $nsmgceoqaqogqmuw); } }
