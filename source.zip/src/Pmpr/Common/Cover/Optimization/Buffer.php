<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661cfd230d559             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\155\x70\x6c\x61\164\145\x5f\162\x65\x64\x69\x72\145\143\x74", [$this, "\163\x75\171\x61\x77\x79\x63\x69\165\145\x63\145\x67\147\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto owmuceyswmgueasi; } ob_start([$this, "\171\x75\x61\145\161\155\x6d\x65\x6f\147\157\167\x6f\141\x65\155"]); owmuceyswmgueasi: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\151\x6d\x69\x7a\141\164\151\x6f\x6e\137\142\165\x66\146\x65\x72", $nsmgceoqaqogqmuw); } }
