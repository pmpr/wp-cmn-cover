<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665c231f04cca             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\155\160\154\141\x74\145\137\162\145\144\x69\x72\145\143\164", [$this, "\163\x75\x79\x61\x77\171\143\151\165\145\143\x65\147\x67\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto miweggwqeiaeweia; } ob_start([$this, "\171\x75\x61\145\161\155\155\145\157\x67\x6f\167\157\x61\145\x6d"]); miweggwqeiaeweia: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\151\155\151\x7a\x61\164\x69\157\156\x5f\142\165\146\x66\145\162", $nsmgceoqaqogqmuw); } }
