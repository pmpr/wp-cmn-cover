<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d88b770bf             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\x6d\x70\154\141\x74\145\x5f\162\145\x64\x69\162\x65\143\x74", [$this, "\x73\165\x79\141\167\171\143\x69\165\145\143\x65\x67\147\x61\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\165\141\x65\161\155\x6d\x65\x6f\147\157\167\157\141\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\x69\x6d\151\x7a\x61\x74\151\x6f\x6e\137\142\165\x66\146\x65\162", $nsmgceoqaqogqmuw); } }
