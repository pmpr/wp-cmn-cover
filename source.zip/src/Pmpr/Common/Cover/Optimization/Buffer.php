<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6c83ea60             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\x6d\160\x6c\x61\164\x65\x5f\x72\x65\x64\x69\x72\x65\143\164", [$this, "\163\165\171\x61\167\x79\143\x69\165\145\143\x65\147\x67\x61\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto omykokikgocoikec; } ob_start([$this, "\171\x75\x61\x65\161\155\x6d\145\x6f\x67\157\x77\157\x61\145\155"]); omykokikgocoikec: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\x69\155\151\x7a\x61\164\151\157\156\x5f\x62\165\146\x66\145\x72", $nsmgceoqaqogqmuw); } }
