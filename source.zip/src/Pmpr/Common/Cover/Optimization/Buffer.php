<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             667883761741c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\x6d\160\154\141\x74\145\137\162\x65\x64\x69\x72\145\x63\x74", [$this, "\163\165\x79\x61\167\171\x63\151\x75\145\x63\145\x67\147\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto osqgywagokmsicqe; } ob_start([$this, "\x79\x75\x61\145\x71\155\155\x65\x6f\147\157\167\157\141\x65\x6d"]); osqgywagokmsicqe: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\x74\151\x6d\151\172\141\x74\151\x6f\156\x5f\142\x75\x66\x66\145\x72", $nsmgceoqaqogqmuw); } }
