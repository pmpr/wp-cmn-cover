<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668107334b816             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\x70\x6c\141\164\145\137\x72\145\144\151\162\x65\143\x74", [$this, "\163\x75\x79\x61\167\x79\143\151\x75\145\x63\145\147\147\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto osqgywagokmsicqe; } ob_start([$this, "\x79\165\141\x65\x71\155\155\x65\157\x67\157\167\157\141\145\155"]); osqgywagokmsicqe: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\x74\151\x6d\151\172\141\x74\x69\157\156\137\142\165\x66\146\145\x72", $nsmgceoqaqogqmuw); } }
