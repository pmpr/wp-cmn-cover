<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6683fecfd1c7e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\155\x70\x6c\x61\164\x65\x5f\162\145\144\151\x72\x65\143\x74", [$this, "\163\x75\171\x61\x77\x79\143\151\x75\145\x63\x65\147\x67\x61\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto osqgywagokmsicqe; } ob_start([$this, "\x79\165\141\x65\161\155\155\145\157\x67\x6f\x77\157\x61\x65\x6d"]); osqgywagokmsicqe: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\x74\151\155\x69\x7a\141\164\x69\x6f\x6e\x5f\x62\x75\x66\x66\145\x72", $nsmgceoqaqogqmuw); } }
