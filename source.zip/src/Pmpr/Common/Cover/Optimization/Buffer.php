<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058600f1ef5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\155\x70\x6c\141\x74\145\x5f\x72\145\x64\151\x72\x65\143\164", [$this, "\163\x75\x79\141\x77\x79\x63\151\x75\145\143\145\147\x67\141\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto kkumywowcoycymeo; } ob_start([$this, "\x79\x75\x61\145\161\155\155\145\x6f\x67\x6f\167\157\141\x65\155"]); kkumywowcoycymeo: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\x74\x69\x6d\x69\172\x61\x74\151\157\156\137\142\x75\146\x66\145\x72", $nsmgceoqaqogqmuw); } }
