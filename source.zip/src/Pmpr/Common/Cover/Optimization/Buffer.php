<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb41cc8f2e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\x70\154\x61\x74\x65\137\162\x65\144\x69\162\x65\143\164", [$this, "\163\165\x79\x61\167\x79\143\x69\x75\x65\143\145\147\147\141\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto omykokikgocoikec; } ob_start([$this, "\x79\165\141\x65\x71\x6d\x6d\145\x6f\147\157\x77\157\141\x65\155"]); omykokikgocoikec: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\164\x69\155\151\172\x61\x74\x69\x6f\x6e\x5f\142\165\x66\146\145\x72", $nsmgceoqaqogqmuw); } }
