<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d8e73847a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\x6d\160\x6c\x61\x74\145\137\162\145\144\x69\162\145\143\x74", [$this, "\163\165\171\x61\167\x79\x63\151\x75\145\x63\145\x67\x67\141\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto kqyoakickmseyyeq; } ob_start([$this, "\171\x75\141\145\161\x6d\155\145\x6f\x67\x6f\x77\x6f\x61\x65\155"]); kqyoakickmseyyeq: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\x69\155\x69\172\141\164\151\157\156\x5f\x62\165\x66\146\x65\x72", $nsmgceoqaqogqmuw); } }
