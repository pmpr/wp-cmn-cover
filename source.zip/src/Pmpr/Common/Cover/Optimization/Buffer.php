<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661cfe171bf2b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\155\x70\x6c\x61\x74\x65\x5f\x72\x65\x64\151\x72\x65\143\x74", [$this, "\163\x75\171\141\167\171\x63\151\x75\145\x63\x65\147\x67\141\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto owmuceyswmgueasi; } ob_start([$this, "\x79\165\141\145\161\x6d\x6d\x65\157\x67\157\167\157\x61\145\155"]); owmuceyswmgueasi: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\151\155\x69\172\x61\164\151\x6f\156\137\x62\x75\x66\x66\145\x72", $nsmgceoqaqogqmuw); } }
