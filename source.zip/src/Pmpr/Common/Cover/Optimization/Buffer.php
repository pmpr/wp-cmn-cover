<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634d52cb393b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\155\160\x6c\141\x74\x65\x5f\162\145\x64\x69\162\145\143\x74", [$this, "\163\x75\171\x61\x77\171\143\151\165\x65\x63\x65\x67\147\141\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto uaicwcqwauosmsqm; } ob_start([$this, "\x79\165\141\145\161\x6d\x6d\145\x6f\147\157\x77\x6f\141\x65\155"]); uaicwcqwauosmsqm: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\164\x69\155\x69\172\x61\164\151\157\x6e\x5f\142\165\146\146\x65\x72", $nsmgceoqaqogqmuw); } }
