<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed8558a25f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\x6d\160\154\x61\164\145\137\162\x65\144\x69\x72\x65\143\164", [$this, "\x73\x75\171\141\167\171\x63\x69\165\x65\143\x65\147\x67\141\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\x75\x61\x65\161\x6d\x6d\x65\x6f\x67\x6f\167\157\x61\x65\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\164\151\x6d\x69\x7a\x61\x74\x69\157\x6e\137\x62\165\146\x66\145\x72", $nsmgceoqaqogqmuw); } }
