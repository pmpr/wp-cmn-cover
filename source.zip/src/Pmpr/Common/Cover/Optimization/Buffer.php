<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d444b29914             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\155\x70\154\x61\164\145\137\162\x65\144\151\x72\x65\143\x74", [$this, "\x73\165\171\x61\167\x79\143\x69\x75\x65\x63\x65\147\x67\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\165\141\x65\161\155\155\145\x6f\147\x6f\x77\x6f\x61\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\151\x6d\x69\172\141\164\x69\x6f\x6e\x5f\142\x75\x66\146\145\162", $nsmgceoqaqogqmuw); } }
