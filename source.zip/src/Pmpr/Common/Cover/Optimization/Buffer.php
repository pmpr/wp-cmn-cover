<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb569a3cb08             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\155\x70\x6c\x61\x74\x65\x5f\162\145\x64\x69\162\x65\x63\164", [$this, "\163\x75\171\141\x77\x79\x63\151\x75\145\143\x65\x67\147\141\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto mocaoayiouggauiy; } ob_start([$this, "\x79\x75\141\145\161\x6d\155\x65\157\x67\x6f\167\157\x61\145\155"]); mocaoayiouggauiy: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\x74\151\x6d\151\x7a\141\164\x69\157\156\x5f\142\x75\146\x66\145\x72", $nsmgceoqaqogqmuw); } }
