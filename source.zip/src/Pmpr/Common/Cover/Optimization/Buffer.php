<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbf0b9b05a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\155\x70\x6c\x61\x74\145\137\162\x65\144\x69\x72\145\x63\164", [$this, "\x73\x75\171\x61\x77\171\143\x69\165\145\143\145\x67\x67\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto kkumywowcoycymeo; } ob_start([$this, "\x79\165\x61\145\161\155\155\145\x6f\147\x6f\x77\157\x61\x65\x6d"]); kkumywowcoycymeo: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\164\x69\x6d\151\172\141\164\x69\157\156\137\x62\x75\146\146\145\x72", $nsmgceoqaqogqmuw); } }
