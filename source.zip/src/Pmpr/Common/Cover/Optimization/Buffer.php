<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd7abdc00             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\155\160\x6c\x61\164\x65\137\x72\x65\x64\151\x72\145\143\x74", [$this, "\163\165\171\x61\x77\171\143\151\x75\x65\143\x65\x67\x67\x61\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\165\141\x65\161\155\x6d\x65\x6f\x67\x6f\167\157\141\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\x74\151\155\x69\172\141\164\151\x6f\156\137\x62\x75\146\x66\145\162", $nsmgceoqaqogqmuw); } }
