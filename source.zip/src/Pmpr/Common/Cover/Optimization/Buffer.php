<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d321c131             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\155\160\154\x61\164\145\x5f\x72\x65\144\x69\162\145\143\164", [$this, "\163\x75\171\x61\x77\x79\x63\x69\x75\145\143\x65\147\x67\x61\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto mocaoayiouggauiy; } ob_start([$this, "\171\x75\141\x65\161\155\x6d\x65\157\x67\x6f\167\x6f\141\x65\x6d"]); mocaoayiouggauiy: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\x74\x69\x6d\x69\x7a\141\164\x69\157\x6e\x5f\142\x75\146\x66\145\162", $nsmgceoqaqogqmuw); } }
