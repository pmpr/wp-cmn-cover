<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce113365b6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\x70\154\141\x74\145\137\x72\x65\144\x69\162\145\x63\x74", [$this, "\163\x75\x79\x61\167\171\143\x69\x75\x65\143\145\x67\x67\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto osqgywagokmsicqe; } ob_start([$this, "\x79\x75\x61\145\x71\155\155\145\157\x67\157\167\x6f\141\145\x6d"]); osqgywagokmsicqe: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\151\155\151\x7a\x61\x74\151\157\x6e\137\x62\165\146\x66\145\x72", $nsmgceoqaqogqmuw); } }
