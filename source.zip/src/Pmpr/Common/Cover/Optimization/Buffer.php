<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f0338f6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\155\x70\154\141\164\x65\137\x72\x65\x64\151\x72\145\x63\x74", [$this, "\163\x75\x79\x61\167\171\x63\x69\x75\x65\143\x65\x67\147\x61\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto miweggwqeiaeweia; } ob_start([$this, "\171\165\141\145\161\x6d\155\x65\157\x67\157\x77\x6f\x61\145\x6d"]); miweggwqeiaeweia: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\x69\155\151\x7a\x61\x74\x69\x6f\156\x5f\x62\x75\x66\146\x65\x72", $nsmgceoqaqogqmuw); } }
