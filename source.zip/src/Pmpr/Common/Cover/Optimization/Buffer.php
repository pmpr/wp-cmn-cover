<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4ae274fd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\x6d\160\154\x61\164\x65\137\162\145\144\x69\x72\145\143\x74", [$this, "\x73\x75\171\141\167\171\143\x69\x75\x65\x63\x65\147\x67\141\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\141\145\x71\155\155\x65\x6f\147\157\x77\157\141\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\x74\151\x6d\151\x7a\141\x74\x69\x6f\156\x5f\142\x75\146\146\145\162", $nsmgceoqaqogqmuw); } }
