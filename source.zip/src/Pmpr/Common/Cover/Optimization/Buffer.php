<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707b80daa6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\x6d\160\154\141\164\x65\x5f\x72\145\x64\x69\x72\145\x63\164", [$this, "\x73\x75\171\141\167\171\143\151\x75\x65\x63\x65\x67\x67\x61\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto osqgywagokmsicqe; } ob_start([$this, "\x79\165\x61\x65\x71\x6d\x6d\145\157\147\x6f\167\157\141\x65\x6d"]); osqgywagokmsicqe: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\x74\151\x6d\x69\x7a\x61\x74\x69\x6f\156\x5f\x62\165\146\x66\145\x72", $nsmgceoqaqogqmuw); } }
