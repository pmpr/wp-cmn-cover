<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a96de33ec             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\155\x70\x6c\141\164\145\x5f\x72\145\x64\151\162\x65\x63\x74", [$this, "\163\x75\171\x61\x77\x79\143\151\165\145\143\145\147\147\x61\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\141\145\161\155\x6d\145\x6f\x67\157\x77\157\x61\x65\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\x74\151\x6d\151\x7a\141\x74\x69\157\x6e\x5f\x62\165\146\x66\145\162", $nsmgceoqaqogqmuw); } }
