<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f2a2573623             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\155\x70\x6c\141\164\x65\x5f\162\145\x64\x69\x72\145\143\x74", [$this, "\163\165\171\141\x77\171\x63\x69\x75\145\x63\x65\x67\147\141\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto eequksumcoogyoem; } ob_start([$this, "\x79\x75\x61\145\161\x6d\155\145\x6f\x67\x6f\x77\x6f\141\x65\155"]); eequksumcoogyoem: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\164\151\x6d\151\x7a\x61\x74\151\x6f\156\137\x62\x75\x66\x66\145\162", $nsmgceoqaqogqmuw); } }
