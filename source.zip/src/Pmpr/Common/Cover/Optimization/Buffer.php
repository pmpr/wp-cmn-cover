<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1d0fddc76             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\160\x6c\x61\x74\x65\x5f\162\145\144\x69\x72\x65\x63\164", [$this, "\163\165\171\141\167\x79\143\151\x75\x65\143\x65\147\x67\x61\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto owmuceyswmgueasi; } ob_start([$this, "\171\x75\141\145\x71\155\x6d\x65\x6f\x67\x6f\x77\x6f\x61\x65\x6d"]); owmuceyswmgueasi: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\164\x69\155\x69\172\141\164\151\x6f\x6e\x5f\x62\x75\x66\146\x65\162", $nsmgceoqaqogqmuw); } }
