<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebd2b1ff7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\x70\x6c\x61\x74\x65\137\162\x65\144\x69\x72\145\143\x74", [$this, "\163\x75\x79\x61\167\171\x63\151\x75\145\143\x65\147\147\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto gkqiqaqecmoogmaa; } ob_start([$this, "\171\x75\141\x65\161\155\x6d\x65\157\x67\157\167\x6f\141\x65\155"]); gkqiqaqecmoogmaa: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\164\151\x6d\x69\x7a\x61\164\x69\x6f\156\x5f\x62\165\146\x66\x65\x72", $nsmgceoqaqogqmuw); } }
