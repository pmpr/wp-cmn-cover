<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66361537dbfa1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\155\160\x6c\x61\164\x65\137\x72\x65\x64\x69\x72\145\x63\x74", [$this, "\x73\x75\171\141\x77\171\x63\151\x75\x65\143\145\x67\147\141\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto uaicwcqwauosmsqm; } ob_start([$this, "\x79\165\141\x65\x71\x6d\155\145\x6f\x67\157\x77\157\x61\x65\x6d"]); uaicwcqwauosmsqm: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\x74\x69\155\151\172\x61\x74\151\157\156\x5f\142\x75\146\x66\x65\162", $nsmgceoqaqogqmuw); } }
