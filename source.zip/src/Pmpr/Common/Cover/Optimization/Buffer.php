<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6683fe509cfdc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\x6d\x70\x6c\x61\164\x65\137\162\x65\144\x69\x72\x65\x63\164", [$this, "\x73\x75\171\141\x77\x79\x63\x69\165\x65\143\145\147\x67\x61\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto osqgywagokmsicqe; } ob_start([$this, "\171\x75\141\x65\x71\155\155\x65\157\147\157\167\x6f\x61\x65\x6d"]); osqgywagokmsicqe: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\x69\155\x69\x7a\141\x74\151\157\x6e\137\x62\165\146\146\145\162", $nsmgceoqaqogqmuw); } }
