<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038baa18e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\x6d\160\x6c\141\x74\145\x5f\162\145\x64\x69\x72\x65\143\x74", [$this, "\x73\165\171\141\167\x79\x63\151\x75\145\143\x65\147\x67\141\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\x75\x61\x65\161\155\155\x65\157\x67\157\x77\x6f\141\x65\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\151\x6d\x69\172\x61\x74\151\x6f\156\137\x62\x75\146\x66\x65\x72", $nsmgceoqaqogqmuw); } }
