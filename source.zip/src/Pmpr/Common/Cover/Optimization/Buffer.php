<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edcfcc58f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\160\154\141\x74\145\x5f\x72\145\x64\151\162\x65\x63\164", [$this, "\163\x75\171\x61\167\171\143\x69\165\145\143\x65\x67\147\141\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto mwieyyqamgwicgco; } ob_start([$this, "\x79\x75\x61\x65\x71\x6d\x6d\x65\157\147\x6f\167\157\141\145\x6d"]); mwieyyqamgwicgco: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\151\155\151\172\x61\164\x69\x6f\156\x5f\142\165\x66\x66\x65\x72", $nsmgceoqaqogqmuw); } }
