<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce633b36061             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\x6d\x70\x6c\141\x74\x65\137\x72\x65\x64\151\x72\145\x63\x74", [$this, "\x73\x75\171\141\x77\171\x63\151\x75\145\143\145\x67\x67\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto osqgywagokmsicqe; } ob_start([$this, "\x79\165\x61\145\161\x6d\x6d\145\x6f\147\157\x77\x6f\141\x65\155"]); osqgywagokmsicqe: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\x74\151\x6d\x69\172\141\164\x69\157\156\x5f\x62\165\146\x66\x65\162", $nsmgceoqaqogqmuw); } }
