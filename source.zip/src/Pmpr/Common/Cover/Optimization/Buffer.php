<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6e5e580d3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\x6d\x70\x6c\x61\164\145\137\162\x65\144\x69\162\145\x63\164", [$this, "\163\165\x79\141\167\x79\143\151\165\145\143\x65\147\147\x61\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto uaicwcqwauosmsqm; } ob_start([$this, "\x79\165\141\145\x71\x6d\155\145\157\x67\157\167\157\x61\145\x6d"]); uaicwcqwauosmsqm: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\x74\x69\x6d\151\x7a\141\164\151\157\x6e\x5f\x62\x75\x66\146\x65\162", $nsmgceoqaqogqmuw); } }
