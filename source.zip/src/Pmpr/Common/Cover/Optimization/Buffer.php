<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661da07985021             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\155\160\x6c\141\164\x65\137\162\x65\x64\151\x72\145\x63\164", [$this, "\163\165\171\141\167\171\x63\151\x75\x65\x63\x65\x67\x67\141\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto owmuceyswmgueasi; } ob_start([$this, "\x79\165\x61\145\x71\155\155\x65\157\147\157\167\157\x61\145\x6d"]); owmuceyswmgueasi: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\x74\151\x6d\x69\172\x61\164\x69\157\x6e\x5f\x62\x75\x66\146\145\162", $nsmgceoqaqogqmuw); } }
