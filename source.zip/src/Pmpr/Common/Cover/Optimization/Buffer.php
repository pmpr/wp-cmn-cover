<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6d105d6a3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\155\x70\x6c\x61\x74\145\137\x72\x65\x64\x69\x72\145\x63\x74", [$this, "\x73\x75\171\x61\167\171\143\x69\165\145\143\145\x67\x67\141\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto uaicwcqwauosmsqm; } ob_start([$this, "\171\x75\x61\145\x71\155\155\145\x6f\x67\157\x77\157\x61\145\155"]); uaicwcqwauosmsqm: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\x74\x69\x6d\151\172\x61\x74\151\x6f\x6e\x5f\142\165\x66\146\x65\x72", $nsmgceoqaqogqmuw); } }
