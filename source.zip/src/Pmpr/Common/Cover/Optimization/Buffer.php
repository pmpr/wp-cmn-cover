<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf77432f3e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\155\x70\154\141\164\x65\x5f\162\x65\144\x69\x72\x65\x63\x74", [$this, "\x73\x75\x79\141\x77\x79\x63\151\165\145\x63\145\147\x67\141\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto uaicwcqwauosmsqm; } ob_start([$this, "\171\165\141\x65\161\x6d\x6d\145\157\147\x6f\167\x6f\141\145\155"]); uaicwcqwauosmsqm: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\x74\x69\155\x69\172\141\164\x69\x6f\x6e\x5f\x62\x75\146\x66\145\162", $nsmgceoqaqogqmuw); } }
