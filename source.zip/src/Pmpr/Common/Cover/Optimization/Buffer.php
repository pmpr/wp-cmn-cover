<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6b8a7124             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\155\x70\154\141\164\145\x5f\162\x65\144\x69\x72\x65\143\x74", [$this, "\163\165\x79\x61\167\171\x63\151\x75\145\x63\x65\147\147\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\x75\x61\145\x71\155\x6d\145\157\147\x6f\x77\157\x61\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\151\155\x69\x7a\x61\x74\x69\157\x6e\137\x62\x75\x66\x66\x65\162", $nsmgceoqaqogqmuw); } }
