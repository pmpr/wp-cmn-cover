<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d5a8e62a84             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\155\160\154\141\x74\145\137\x72\x65\144\151\162\x65\143\x74", [$this, "\163\x75\171\x61\167\x79\143\x69\x75\145\143\145\x67\147\141\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto uaicwcqwauosmsqm; } ob_start([$this, "\x79\165\141\145\x71\155\155\145\x6f\147\157\167\x6f\141\x65\x6d"]); uaicwcqwauosmsqm: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\x74\x69\155\x69\x7a\141\x74\151\157\156\x5f\142\165\146\146\145\162", $nsmgceoqaqogqmuw); } }
