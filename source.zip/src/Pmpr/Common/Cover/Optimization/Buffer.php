<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8e22e6a39             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\x6d\x70\154\x61\164\145\x5f\162\x65\144\151\162\x65\x63\164", [$this, "\163\x75\x79\x61\167\x79\x63\151\x75\x65\x63\x65\147\147\141\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto uaicwcqwauosmsqm; } ob_start([$this, "\171\165\x61\x65\x71\155\x6d\x65\157\147\x6f\x77\157\x61\145\155"]); uaicwcqwauosmsqm: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\x69\x6d\151\x7a\141\164\x69\157\x6e\x5f\x62\x75\146\x66\x65\162", $nsmgceoqaqogqmuw); } }
