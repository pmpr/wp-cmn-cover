<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6cc684087             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\x6d\160\x6c\x61\164\x65\x5f\x72\145\144\x69\162\x65\143\164", [$this, "\163\x75\x79\x61\x77\171\143\x69\x75\x65\x63\x65\147\x67\141\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto osqgywagokmsicqe; } ob_start([$this, "\x79\x75\x61\145\x71\x6d\x6d\145\157\x67\x6f\167\x6f\141\x65\x6d"]); osqgywagokmsicqe: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\x74\x69\155\151\x7a\x61\x74\x69\157\x6e\x5f\142\x75\x66\x66\x65\x72", $nsmgceoqaqogqmuw); } }
