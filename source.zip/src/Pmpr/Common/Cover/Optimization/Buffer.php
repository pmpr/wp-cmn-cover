<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d45f99e4b5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\155\160\x6c\x61\x74\x65\x5f\162\x65\x64\151\x72\x65\143\x74", [$this, "\x73\165\171\141\167\x79\143\x69\x75\145\x63\145\147\147\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto uaicwcqwauosmsqm; } ob_start([$this, "\171\165\141\x65\x71\x6d\155\145\x6f\x67\x6f\x77\157\x61\145\155"]); uaicwcqwauosmsqm: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\x69\x6d\x69\172\141\164\x69\157\156\x5f\x62\165\x66\146\x65\162", $nsmgceoqaqogqmuw); } }
