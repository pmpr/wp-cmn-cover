<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634f31ce478f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\x6d\x70\154\x61\164\145\137\162\145\144\151\162\x65\143\x74", [$this, "\x73\x75\x79\141\x77\171\x63\x69\x75\145\143\145\x67\x67\x61\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto uaicwcqwauosmsqm; } ob_start([$this, "\171\165\141\145\161\x6d\155\x65\x6f\147\x6f\x77\157\x61\145\x6d"]); uaicwcqwauosmsqm: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\x69\x6d\x69\x7a\x61\164\x69\157\156\x5f\142\x75\146\x66\145\162", $nsmgceoqaqogqmuw); } }
