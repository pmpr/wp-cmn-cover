<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661cfd230d559             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\57\164\x79\x70\x65\x3d\x5b\x27\42\135\164\145\x78\164\134\57\50\x6a\141\x76\141\163\x63\162\151\x70\164\174\x63\163\163\51\x5b\x27\42\x5d\57", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
