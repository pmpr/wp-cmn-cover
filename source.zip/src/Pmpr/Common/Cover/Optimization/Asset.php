<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf77432f3e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\x2f\164\x79\x70\x65\x3d\x5b\47\x22\135\164\145\170\164\x5c\57\50\x6a\141\166\x61\163\143\162\x69\x70\164\174\143\x73\163\x29\x5b\47\42\135\57", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
