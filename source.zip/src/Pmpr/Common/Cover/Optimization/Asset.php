<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66361537dbfa1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\57\164\x79\160\x65\75\133\47\42\x5d\164\x65\x78\164\134\57\x28\152\141\x76\x61\163\143\162\x69\x70\x74\174\x63\x73\163\51\133\x27\42\x5d\x2f", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
