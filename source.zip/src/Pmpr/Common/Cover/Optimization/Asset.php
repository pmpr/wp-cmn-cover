<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6683fecfd1c7e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\57\164\x79\x70\145\x3d\x5b\x27\42\x5d\164\x65\x78\x74\134\x2f\50\152\x61\166\141\x73\x63\x72\151\160\x74\x7c\143\x73\163\x29\133\47\x22\x5d\57", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
