<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707b80daa6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\x2f\164\x79\x70\145\x3d\x5b\x27\42\x5d\x74\x65\x78\164\x5c\x2f\50\152\x61\166\x61\163\x63\162\151\160\x74\x7c\x63\163\163\51\x5b\47\x22\135\x2f", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
