<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6952c9cee0318             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; use Pmpr\Common\Cover\Optimization\Common as BaseClass; abstract class Common extends BaseClass { }
