<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b702ccb594e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Cache extends Common { }
