<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce113365b6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Cache extends Common { }
