<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb569a3cb08             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Cache extends Common { }
