<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68078170d9cc3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Buffer { }
