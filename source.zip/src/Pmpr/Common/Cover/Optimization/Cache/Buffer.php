<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6807bbf13dada             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Buffer { }
