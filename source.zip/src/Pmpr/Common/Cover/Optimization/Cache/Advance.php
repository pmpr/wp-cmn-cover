<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67e1692a50e9f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Advance extends Common { }
