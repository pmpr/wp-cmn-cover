<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb41cc8f2e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Purge extends Common { }
