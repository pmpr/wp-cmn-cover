<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1d0fddc76             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Purge extends Common { }
