<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522cf903aeb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\PageBuilder; use Pmpr\Common\Cover\Container; class PageBuilder extends Container { }
