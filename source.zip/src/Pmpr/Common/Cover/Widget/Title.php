<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8e22e6a39             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; class Title extends Common { public function __construct() { parent::__construct(__("\x54\151\x74\154\145", PR__CMN__COVER), __("\x44\x69\163\x70\x6c\x61\x79\x20\x74\150\145\x20\x74\x69\164\x6c\x65\x2e", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\145\x78\164", PR__CMN__COVER))); } }
