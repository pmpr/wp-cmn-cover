<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d321c131             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; class Title extends Common { public function __construct() { parent::__construct(__("\x54\x69\164\154\x65", PR__CMN__COVER), __("\x44\151\163\160\x6c\141\x79\40\164\150\145\x20\x74\151\164\154\145\56", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\145\170\164", PR__CMN__COVER))); } }
