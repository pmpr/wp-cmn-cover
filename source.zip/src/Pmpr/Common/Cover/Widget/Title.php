<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             667883761741c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; class Title extends Common { public function __construct() { parent::__construct(__("\x54\x69\x74\x6c\x65", PR__CMN__COVER), __("\x44\151\x73\160\x6c\x61\171\x20\x74\x68\145\x20\x74\151\x74\154\x65\x2e", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\145\170\164", PR__CMN__COVER))); } }
