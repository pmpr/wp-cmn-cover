<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1d0fddc76             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; class Title extends Common { public function __construct() { parent::__construct(__("\x54\x69\164\154\145", PR__CMN__COVER), __("\x44\151\x73\x70\x6c\141\171\x20\164\x68\145\x20\164\x69\164\154\145\56", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\x65\170\164", PR__CMN__COVER))); } }
