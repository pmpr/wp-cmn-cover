<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665c231f04cca             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; class Title extends Common { public function __construct() { parent::__construct(__("\124\151\164\154\x65", PR__CMN__COVER), __("\104\151\163\x70\x6c\141\x79\x20\x74\x68\x65\x20\x74\x69\x74\154\145\56", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\x54\145\x78\x74", PR__CMN__COVER))); } }
