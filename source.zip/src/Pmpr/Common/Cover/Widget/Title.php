<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522cf903aeb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Title extends Widget { public function __construct() { parent::__construct(__("\124\151\164\154\145", PR__CMN__COVER), __("\x44\151\x73\160\x6c\141\171\40\164\150\145\x20\164\x69\164\154\145\56", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\145\170\164", PR__CMN__COVER))); } }
