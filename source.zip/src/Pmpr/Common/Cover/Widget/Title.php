<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d444b29914             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Title extends Widget { public function __construct() { parent::__construct(__("\124\x69\164\x6c\145", PR__CMN__COVER), __("\x44\151\x73\x70\154\x61\x79\x20\x74\150\x65\x20\x74\151\x74\154\145\56", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\x65\x78\x74", PR__CMN__COVER))); } }
