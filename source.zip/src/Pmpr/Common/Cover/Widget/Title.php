<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4ba10c294             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Title extends Common { public function __construct() { parent::__construct(__("\124\x69\164\x6c\145", PR__CMN__COVER), __("\x44\x69\163\160\x6c\141\x79\x20\x74\150\x65\40\164\151\x74\154\x65\x2e", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\145\170\x74", PR__CMN__COVER))); } }
