<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637dd936a824             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; class Title extends Common { public function __construct() { parent::__construct(__("\124\151\x74\154\145", PR__CMN__COVER), __("\104\x69\163\x70\x6c\141\171\40\164\150\x65\x20\x74\151\164\x6c\x65\x2e", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\x54\x65\x78\x74", PR__CMN__COVER))); } }
