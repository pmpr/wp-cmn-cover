<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66361537dbfa1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; class Title extends Common { public function __construct() { parent::__construct(__("\x54\151\x74\x6c\x65", PR__CMN__COVER), __("\x44\x69\163\160\x6c\x61\171\40\x74\150\145\40\164\151\x74\x6c\145\56", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\x54\145\x78\164", PR__CMN__COVER))); } }
