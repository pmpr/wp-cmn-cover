<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edcfcc58f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; class Title extends Common { public function __construct() { parent::__construct(__("\124\x69\x74\154\145", PR__CMN__COVER), __("\x44\x69\163\160\154\x61\171\40\x74\150\145\x20\x74\x69\x74\x6c\x65\56", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\145\x78\x74", PR__CMN__COVER))); } }
