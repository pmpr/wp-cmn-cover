<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85a3b171             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Title extends Common { public function __construct() { parent::__construct(__("\x54\151\x74\x6c\145", PR__CMN__COVER), __("\104\151\x73\160\x6c\x61\171\40\164\x68\145\40\164\151\x74\154\x65\x2e", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\x65\170\164", PR__CMN__COVER))); } }
