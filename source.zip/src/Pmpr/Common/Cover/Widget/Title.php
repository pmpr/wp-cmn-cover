<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058600f1ef5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; class Title extends Common { public function __construct() { parent::__construct(__("\x54\x69\164\154\145", PR__CMN__COVER), __("\104\151\x73\x70\x6c\141\171\x20\x74\150\x65\40\x74\151\164\x6c\x65\56", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\x54\145\170\164", PR__CMN__COVER))); } }
