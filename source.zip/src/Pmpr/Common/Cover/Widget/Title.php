<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6683fe509cfdc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; class Title extends Common { public function __construct() { parent::__construct(__("\124\x69\164\x6c\145", PR__CMN__COVER), __("\x44\x69\163\x70\x6c\x61\x79\x20\x74\x68\145\40\164\x69\164\154\x65\x2e", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\x54\x65\x78\164", PR__CMN__COVER))); } }
