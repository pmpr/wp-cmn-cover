<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6d105d6a3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; class Title extends Common { public function __construct() { parent::__construct(__("\124\151\x74\x6c\145", PR__CMN__COVER), __("\104\x69\163\x70\x6c\x61\x79\40\164\150\145\40\164\x69\164\x6c\x65\x2e", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\x54\x65\x78\x74", PR__CMN__COVER))); } }
