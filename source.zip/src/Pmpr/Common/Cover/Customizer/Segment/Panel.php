<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d8e73847a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Segment; class Panel extends Segment { protected ?string $type = "\x57\x50\x5f\x43\x75\163\x74\x6f\155\x69\x7a\145\137\x50\x61\x6e\145\154"; protected ?array $sections = []; public function suuogccckocgseyg() : ?array { return $this->sections; } public function kwkugmqouisgkqig(Section $awcmekyiwwkeyisq) : self { $awcmekyiwwkeyisq->ouuceooysqugqmee($this->mwikyscisascoeea()); $this->sections[$awcmekyiwwkeyisq->mwikyscisascoeea()] = $awcmekyiwwkeyisq; return $this; } }
