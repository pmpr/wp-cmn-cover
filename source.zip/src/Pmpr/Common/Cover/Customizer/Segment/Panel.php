<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038baa18e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Segment; class Panel extends Segment { protected ?string $type = "\127\120\137\x43\165\163\x74\157\x6d\x69\172\145\137\120\x61\x6e\145\x6c"; protected ?array $sections = []; public function suuogccckocgseyg() : ?array { return $this->sections; } public function kwkugmqouisgkqig(Section $awcmekyiwwkeyisq) : self { $awcmekyiwwkeyisq->ouuceooysqugqmee($this->mwikyscisascoeea()); $this->sections[$awcmekyiwwkeyisq->mwikyscisascoeea()] = $awcmekyiwwkeyisq; return $this; } }
