<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a96de33ec             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Segment; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; class Section extends Segment { protected ?string $type = "\127\x50\x5f\x43\165\163\164\x6f\x6d\151\x7a\x65\137\x53\145\143\x74\x69\157\x6e"; protected array $fields = []; protected ?string $panel = null; public function ouuceooysqugqmee(?string $skeuoeoiuwwyqwou) : self { $this->panel = $skeuoeoiuwwyqwou; return $this; } public function ugmceccgwaaaigiy() : array { return $this->fields; } public function mkksewyosgeumwsa(Field $aiowsaccomcoikus) : self { $this->fields[$aiowsaccomcoikus->mwikyscisascoeea()] = $aiowsaccomcoikus; return $this; } public function ewweaossowcqywaw($ikgwqyuyckaewsow) : self { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { $this->mkksewyosgeumwsa($aiowsaccomcoikus); } return $this; } }
