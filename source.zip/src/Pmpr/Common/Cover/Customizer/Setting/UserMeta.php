<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038baa18e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; class UserMeta extends Setting { }
