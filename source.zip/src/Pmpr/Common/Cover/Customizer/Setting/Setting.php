<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d444b29914             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\150\x65\x6d\x65\137\x6d\157\x64"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\x72\x61\156\163\x70\x6f\162\x74" => "\162\x65\146\x72\145\163\150", "\x63\x61\x70\141\142\151\154\151\164\x79" => "\x65\144\151\x74\x5f\164\x68\145\x6d\x65\137\157\x70\x74\151\x6f\x6e\163", "\144\x65\x66\x61\x75\x6c\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\x61\156\151\x74\x69\x7a\145\137\143\141\154\x6c\x62\141\143\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
