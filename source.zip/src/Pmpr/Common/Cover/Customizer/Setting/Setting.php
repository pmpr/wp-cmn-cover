<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038baa18e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\x68\145\155\145\137\155\x6f\x64"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\162\x61\156\x73\x70\x6f\x72\164" => "\162\x65\x66\x72\145\x73\x68", "\x63\141\160\141\142\151\154\x69\164\171" => "\x65\x64\151\164\137\164\150\x65\155\145\x5f\157\x70\164\x69\x6f\156\x73", "\x64\x65\x66\141\x75\x6c\x74" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\x73\141\156\x69\164\151\172\x65\137\x63\141\x6c\154\x62\141\x63\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
