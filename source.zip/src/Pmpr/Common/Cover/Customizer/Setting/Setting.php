<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd7abdc00             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\150\x65\x6d\x65\x5f\155\x6f\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\x72\x61\x6e\163\160\x6f\162\164" => "\x72\x65\x66\162\145\x73\x68", "\143\x61\x70\x61\142\x69\154\151\164\171" => "\x65\144\151\164\x5f\x74\x68\145\x6d\x65\x5f\x6f\x70\164\151\x6f\156\163", "\144\145\146\x61\x75\x6c\x74" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\141\156\151\x74\x69\x7a\x65\137\143\x61\154\154\142\141\x63\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
