<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6b8a7124             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\164\150\x65\x6d\145\x5f\x6d\157\x64"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\x72\x61\156\x73\x70\157\x72\x74" => "\162\145\x66\x72\x65\163\x68", "\143\x61\160\141\x62\x69\154\x69\x74\171" => "\145\x64\x69\x74\137\164\150\x65\x6d\x65\137\x6f\160\164\x69\157\x6e\x73", "\x64\x65\146\x61\x75\x6c\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\x73\141\x6e\151\164\x69\x7a\145\137\x63\x61\154\154\142\141\x63\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
