<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678030c3dd532             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\150\145\155\145\137\155\157\x64"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\x72\x61\156\163\x70\x6f\162\164" => "\162\x65\146\x72\145\x73\x68", "\143\x61\x70\141\x62\x69\154\151\164\x79" => "\x65\x64\x69\164\x5f\164\x68\145\x6d\145\137\x6f\x70\164\x69\x6f\x6e\163", "\x64\x65\x66\x61\165\x6c\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\x61\x6e\151\164\x69\172\x65\x5f\143\x61\x6c\154\142\x61\x63\x6b" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
