<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85a3b171             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\x65\x6c\x6f\160\x20\x61\x6e\x64\x20\x44\x65\163\151\147\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\162\x64\160\162\145\x73\163\55\x77\x65\x62\55\x64\x65\x73\x69\147\x6e\x2d\144\145\166\145\x6c\x6f\x70\155\145\156\164"); } }
