<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fcb2eda4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\145\x6c\x6f\x70\x20\141\156\144\x20\104\145\163\151\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\157\162\x64\x70\x72\x65\163\x73\55\x77\x65\142\55\x64\145\x73\x69\147\x6e\55\144\x65\166\x65\154\x6f\160\x6d\x65\x6e\x74"); } }
