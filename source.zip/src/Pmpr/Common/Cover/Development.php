<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a83354743             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\166\145\x6c\x6f\x70\40\141\156\x64\40\x44\x65\163\x69\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\x72\144\160\x72\145\x73\x73\55\x77\x65\x62\x2d\144\x65\163\151\147\x6e\x2d\x64\x65\x76\145\154\x6f\x70\155\x65\156\x74"); } }
