<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed8558a25f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\x65\154\x6f\160\x20\x61\x6e\144\40\104\145\163\x69\147\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\162\144\160\x72\x65\x73\x73\x2d\167\145\142\x2d\x64\x65\x73\x69\147\x6e\55\144\x65\166\x65\x6c\157\160\x6d\145\156\164"); } }
