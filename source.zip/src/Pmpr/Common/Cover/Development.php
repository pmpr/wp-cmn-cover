<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d88b770bf             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\145\166\145\154\157\x70\x20\x61\156\144\40\x44\145\163\151\x67\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\x72\x64\x70\162\145\x73\163\x2d\x77\x65\x62\55\x64\x65\163\151\x67\156\55\144\x65\x76\145\x6c\x6f\160\155\x65\x6e\164"); } }
