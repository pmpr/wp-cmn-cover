<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522cf903aeb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\x76\x65\154\157\160\x20\141\156\144\40\x44\145\x73\151\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\x72\x64\160\162\145\x73\163\x2d\x77\x65\142\x2d\144\x65\x73\151\x67\x6e\55\x64\x65\x76\x65\154\x6f\x70\155\x65\x6e\x74"); } }
