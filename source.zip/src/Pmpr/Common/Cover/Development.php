<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a96de33ec             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\x76\145\x6c\157\160\40\141\156\144\40\x44\145\163\151\147\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\x6f\x72\x64\x70\162\145\x73\163\55\167\x65\142\55\x64\145\163\x69\147\156\55\x64\145\x76\145\154\x6f\x70\155\x65\x6e\x74"); } }
