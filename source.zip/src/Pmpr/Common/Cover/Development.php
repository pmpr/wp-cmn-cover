<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a7eec562             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\145\x76\x65\154\157\x70\40\141\x6e\144\40\104\x65\163\151\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\x72\x64\x70\x72\x65\x73\x73\x2d\x77\145\x62\x2d\144\x65\x73\x69\x67\156\55\144\x65\166\145\x6c\x6f\x70\155\x65\x6e\x74"); } }
