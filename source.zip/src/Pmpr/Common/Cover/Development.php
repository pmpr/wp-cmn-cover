<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce633b36061             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\166\145\x6c\157\x70\x20\x61\x6e\144\x20\x44\x65\163\x69\x67\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\162\144\160\x72\145\163\x73\55\x77\x65\142\x2d\144\x65\x73\x69\147\156\x2d\144\x65\x76\145\x6c\x6f\160\155\x65\x6e\x74"); } }
