<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038baa18e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\145\154\x6f\160\x20\141\x6e\144\x20\x44\x65\x73\151\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\x72\144\160\x72\145\163\x73\55\167\145\142\x2d\144\145\x73\x69\147\x6e\x2d\x64\145\x76\x65\x6c\x6f\160\155\145\x6e\x74"); } }
