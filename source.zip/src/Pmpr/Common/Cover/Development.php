<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6c83ea60             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\x76\x65\x6c\x6f\x70\x20\x61\156\144\x20\104\145\163\151\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\162\144\160\x72\145\x73\163\x2d\x77\145\142\55\x64\145\x73\151\x67\156\x2d\144\145\x76\145\154\157\160\155\145\x6e\x74"); } }
