<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6cc684087             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\145\x6c\157\x70\40\x61\x6e\144\x20\x44\145\163\151\147\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\x6f\162\x64\160\162\145\x73\163\55\x77\x65\x62\55\x64\145\x73\151\147\x6e\x2d\x64\145\166\145\154\157\160\155\145\156\x74"); } }
