<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb41cc8f2e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\166\x65\x6c\x6f\x70\40\141\156\144\x20\x44\145\163\x69\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\157\x72\144\160\x72\x65\x73\x73\x2d\x77\x65\142\x2d\144\x65\x73\151\x67\156\x2d\x64\145\166\x65\154\157\160\x6d\x65\156\164"); } }
