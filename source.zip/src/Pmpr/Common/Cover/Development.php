<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce113365b6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\145\x76\145\x6c\157\160\x20\141\156\144\40\104\x65\x73\151\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\162\x64\160\x72\145\x73\x73\55\x77\x65\x62\55\144\x65\x73\x69\x67\x6e\x2d\x64\x65\166\145\x6c\157\160\x6d\x65\x6e\x74"); } }
