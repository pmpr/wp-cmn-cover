<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6744598eb4de3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\x65\x6c\x6f\x70\40\x61\156\144\40\x44\145\x73\151\x67\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\162\x64\160\x72\145\x73\x73\55\x77\145\142\x2d\x64\145\x73\151\147\x6e\55\144\145\166\x65\154\157\160\155\145\156\x74"); } }
