<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d444b29914             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\x76\x65\154\157\x70\x20\x61\x6e\x64\x20\104\145\x73\151\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\x72\144\160\x72\145\x73\163\x2d\167\145\x62\55\x64\x65\x73\151\x67\156\55\x64\145\166\x65\154\157\160\x6d\x65\156\x74"); } }
