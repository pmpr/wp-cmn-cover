<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4ba10c294             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\166\145\154\157\x70\x20\141\x6e\144\40\104\x65\x73\151\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\x6f\x72\144\x70\x72\145\x73\163\x2d\167\145\x62\55\144\x65\163\x69\x67\156\55\144\145\x76\145\x6c\157\160\x6d\x65\x6e\x74"); } }
