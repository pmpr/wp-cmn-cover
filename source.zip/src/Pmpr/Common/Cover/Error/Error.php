<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d33736ca             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Error; use Pmpr\Common\Cover\Container; class Error extends Container { public function mameiwsayuyquoeq() { WPDie::symcgieuakksimmu(); } }
