<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634f31ce478f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Setting; class SiteOption extends Setting { public $type = "\x73\151\x74\x65\137\157\x70\164\151\157\x6e"; protected function get_root_value($ggauoeuaesiymgee = null) { return $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->kuaqqosyyoqiueym($this->id_data["\x62\x61\163\x65"], $ggauoeuaesiymgee); } protected function set_root_value($eqgoocgaqwqcimie) : bool { return $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->okkueywgeygcooye($this->id_data["\x62\x61\x73\145"], $eqgoocgaqwqcimie); } protected function update($eqgoocgaqwqcimie) : bool { return $this->set_root_value($eqgoocgaqwqcimie); } public function value() { return $this->get_root_value($this->default); } }
