<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edcfcc58f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Setting; class SiteOption extends Setting { public $type = "\x73\151\164\x65\x5f\157\160\x74\151\x6f\156"; protected function get_root_value($ggauoeuaesiymgee = null) { return $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->kuaqqosyyoqiueym($this->id_data["\x62\141\163\145"], $ggauoeuaesiymgee); } protected function set_root_value($eqgoocgaqwqcimie) : bool { return $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->okkueywgeygcooye($this->id_data["\x62\141\x73\145"], $eqgoocgaqwqcimie); } protected function update($eqgoocgaqwqcimie) : bool { return $this->set_root_value($eqgoocgaqwqcimie); } public function value() { return $this->get_root_value($this->default); } }
