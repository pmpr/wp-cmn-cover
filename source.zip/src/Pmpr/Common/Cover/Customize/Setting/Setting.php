<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1d0fddc76             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Setting; use Pmpr\Common\Foundation\FormMaker\Admin\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\x68\145\155\145\137\x6d\x6f\x64"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\164\162\x61\x6e\163\x70\157\x72\x74" => "\x72\145\x66\162\145\163\150", "\x63\x61\x70\141\142\x69\154\x69\164\x79" => "\145\x64\x69\164\137\164\x68\145\x6d\x65\x5f\157\x70\x74\151\x6f\156\x73", "\x64\x65\146\141\x75\154\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\x61\156\x69\x74\151\x7a\145\x5f\x63\141\x6c\154\142\141\x63\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
