<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbf0b9b05a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Setting; use Pmpr\Common\Foundation\FormMaker\Admin\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\150\145\155\x65\x5f\x6d\157\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\x72\141\156\163\160\x6f\x72\164" => "\x72\145\146\x72\145\x73\x68", "\x63\141\160\141\x62\x69\x6c\151\164\x79" => "\x65\x64\x69\x74\137\x74\150\145\155\145\x5f\x6f\x70\x74\x69\157\x6e\x73", "\144\145\146\141\165\x6c\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\141\156\151\x74\151\172\x65\x5f\x63\141\x6c\154\x62\x61\143\x6b" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
