<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661da07985021             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Setting; use Pmpr\Common\Foundation\FormMaker\Admin\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\164\150\x65\155\145\x5f\x6d\157\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\x72\141\156\x73\160\157\162\x74" => "\x72\x65\x66\x72\x65\x73\150", "\x63\141\160\x61\x62\x69\154\x69\x74\x79" => "\145\144\x69\164\137\x74\150\145\x6d\x65\x5f\x6f\x70\164\151\157\156\163", "\x64\x65\x66\141\x75\154\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\141\156\151\x74\151\x7a\145\x5f\x63\141\154\154\142\141\143\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
