<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6e5e580d3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\164\x68\x65\x6d\x65\137\x6d\157\x64"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\164\162\141\156\x73\160\x6f\x72\164" => "\162\x65\146\162\145\x73\150", "\143\141\x70\x61\142\151\154\151\164\171" => "\145\144\x69\x74\137\164\150\x65\155\145\x5f\157\x70\x74\x69\157\156\x73", "\x64\x65\146\x61\165\154\x74" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\x61\x6e\151\164\x69\x7a\x65\x5f\143\x61\154\x6c\142\141\x63\x6b" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
