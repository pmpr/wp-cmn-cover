<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f0338f6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\150\145\x6d\145\137\155\x6f\x64"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\164\162\x61\156\x73\160\x6f\x72\x74" => "\162\x65\x66\162\145\x73\150", "\143\141\160\141\142\x69\154\151\164\171" => "\x65\x64\151\164\x5f\164\x68\145\155\145\x5f\157\160\x74\x69\x6f\156\163", "\144\x65\146\141\165\x6c\x74" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\x73\141\x6e\151\164\151\172\x65\137\143\x61\154\154\142\141\x63\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
