<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661cfd230d559             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Setting; use Pmpr\Common\Foundation\FormMaker\Admin\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\x68\145\x6d\x65\x5f\155\x6f\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\164\162\x61\156\x73\x70\x6f\162\x74" => "\x72\145\x66\x72\145\163\150", "\x63\141\x70\x61\142\151\x6c\151\164\171" => "\x65\x64\151\164\137\x74\x68\145\155\145\x5f\157\x70\164\151\157\156\x73", "\144\x65\x66\x61\x75\154\x74" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\x73\x61\156\151\164\x69\172\x65\137\143\141\154\154\x62\x61\143\x6b" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
