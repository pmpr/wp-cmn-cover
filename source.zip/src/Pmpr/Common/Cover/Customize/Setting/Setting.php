<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf77432f3e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\x68\145\x6d\x65\x5f\155\x6f\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\x72\x61\x6e\x73\160\x6f\162\x74" => "\x72\x65\x66\x72\145\x73\x68", "\143\141\160\141\x62\x69\154\x69\x74\171" => "\145\x64\151\x74\137\x74\x68\145\155\145\x5f\157\160\x74\151\x6f\x6e\x73", "\144\145\146\141\x75\154\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\141\156\151\x74\x69\172\145\x5f\143\x61\x6c\154\x62\141\143\x6b" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
