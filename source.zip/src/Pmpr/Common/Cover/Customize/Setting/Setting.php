<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634d52cb393b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\164\x68\x65\x6d\x65\x5f\155\x6f\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\164\x72\x61\x6e\x73\160\157\162\x74" => "\x72\x65\x66\x72\x65\163\150", "\x63\141\160\x61\142\151\154\x69\x74\171" => "\145\x64\151\164\137\x74\150\145\x6d\x65\137\x6f\x70\164\x69\x6f\x6e\163", "\x64\145\146\x61\x75\154\x74" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\x61\x6e\151\x74\151\x7a\x65\137\143\141\x6c\x6c\x62\x61\x63\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
