<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058600f1ef5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Setting; use Pmpr\Common\Foundation\FormMaker\Admin\Field\Field; use Pmpr\Common\Foundation\Helper\Traits\HelperTrait; use Pmpr\Common\Foundation\Wrapper\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\164\150\145\x6d\x65\x5f\x6d\157\x64"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\164\162\x61\156\163\x70\157\162\x74" => "\162\145\146\162\x65\163\x68", "\x63\x61\160\x61\x62\x69\154\x69\x74\x79" => "\145\144\151\164\137\x74\150\145\155\x65\x5f\157\160\x74\151\x6f\156\163", "\x64\145\146\x61\x75\x6c\x74" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\x73\x61\x6e\x69\164\x69\x7a\145\137\143\141\154\154\142\141\143\x6b" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
