<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90935bcac             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Setting; class UserMeta extends Setting { }
