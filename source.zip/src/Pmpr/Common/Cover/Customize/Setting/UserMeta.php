<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6cc684087             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Setting; class UserMeta extends Setting { }
