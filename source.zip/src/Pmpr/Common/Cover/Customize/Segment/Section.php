<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661cfd230d559             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Segment; use Pmpr\Common\Foundation\FormMaker\Admin\Field\Field; class Section extends Segment { protected ?string $type = "\127\x50\137\103\165\163\164\x6f\155\x69\x7a\145\x5f\x53\x65\x63\164\151\x6f\x6e"; protected array $fields = []; protected ?string $panel = null; public function ouuceooysqugqmee(?string $skeuoeoiuwwyqwou) : self { $this->panel = $skeuoeoiuwwyqwou; return $this; } public function ugmceccgwaaaigiy() : array { return $this->fields; } public function mkksewyosgeumwsa(Field $aiowsaccomcoikus) : self { $this->fields[$aiowsaccomcoikus->mwikyscisascoeea()] = $aiowsaccomcoikus; return $this; } public function ewweaossowcqywaw($ikgwqyuyckaewsow) : self { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { $this->mkksewyosgeumwsa($aiowsaccomcoikus); yuoamgkigcwaooqu: } kaiqsuaywyuckuoo: return $this; } }
