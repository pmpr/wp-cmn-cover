<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6683fe509cfdc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Segment; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; class Section extends Segment { protected ?string $type = "\127\x50\x5f\x43\165\163\164\157\x6d\151\172\x65\137\123\x65\143\x74\x69\157\156"; protected array $fields = []; protected ?string $panel = null; public function ouuceooysqugqmee(?string $skeuoeoiuwwyqwou) : self { $this->panel = $skeuoeoiuwwyqwou; return $this; } public function ugmceccgwaaaigiy() : array { return $this->fields; } public function mkksewyosgeumwsa(Field $aiowsaccomcoikus) : self { $this->fields[$aiowsaccomcoikus->mwikyscisascoeea()] = $aiowsaccomcoikus; return $this; } public function ewweaossowcqywaw($ikgwqyuyckaewsow) : self { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { $this->mkksewyosgeumwsa($aiowsaccomcoikus); kiwqkcaekqqyuegq: } qsygcycwieukkgwc: return $this; } }
