<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90935bcac             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Segment; class Panel extends Segment { protected ?string $type = "\x57\x50\137\103\x75\163\x74\x6f\155\x69\x7a\x65\137\x50\141\x6e\x65\154"; protected ?array $sections = []; public function suuogccckocgseyg() : ?array { return $this->sections; } public function kwkugmqouisgkqig(Section $awcmekyiwwkeyisq) : self { $awcmekyiwwkeyisq->ouuceooysqugqmee($this->mwikyscisascoeea()); $this->sections[$awcmekyiwwkeyisq->mwikyscisascoeea()] = $awcmekyiwwkeyisq; return $this; } }
