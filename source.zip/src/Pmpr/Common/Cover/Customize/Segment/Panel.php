<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6d105d6a3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Segment; class Panel extends Segment { protected ?string $type = "\127\120\137\103\165\163\x74\x6f\155\151\172\x65\x5f\x50\141\x6e\145\x6c"; protected ?array $sections = []; public function suuogccckocgseyg() : ?array { return $this->sections; } public function kwkugmqouisgkqig(Section $awcmekyiwwkeyisq) : self { $awcmekyiwwkeyisq->ouuceooysqugqmee($this->mwikyscisascoeea()); $this->sections[$awcmekyiwwkeyisq->mwikyscisascoeea()] = $awcmekyiwwkeyisq; return $this; } }
