<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbf0b9b05a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Segment; class Panel extends Segment { protected ?string $type = "\x57\120\137\x43\x75\x73\164\x6f\x6d\x69\172\145\x5f\x50\x61\156\x65\154"; protected ?array $sections = []; public function suuogccckocgseyg() : ?array { return $this->sections; } public function kwkugmqouisgkqig(Section $awcmekyiwwkeyisq) : self { $awcmekyiwwkeyisq->ouuceooysqugqmee($this->mwikyscisascoeea()); $this->sections[$awcmekyiwwkeyisq->mwikyscisascoeea()] = $awcmekyiwwkeyisq; return $this; } }
