<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a83354743             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Search; use Pmpr\Common\Cover\Container; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class Common extends Container { const ecuwamcuymyycucq = Constants::ycusscwsoggmuweq . "\x5f\x73\x65\x61\162\x63\150\137"; public function awwoqyciiocumkqq() { $ccamueccusigaaio = $this->caokeucsksukesyo()->giiecckwoyiawoyy()->yyqgamuwwakgciey(Constants::mgsccwumkcawaqcy, Constants::yyoaeaaaquyigiim); return $this->ocksiywmkyaqseou("\163\145\141\x72\143\x68\137\164\x61\x72\x67\145\x74", $ccamueccusigaaio); } public function sesseaeskwkeucks() : string { $imuiukuiocoayoww = $this->weysguygiseoukqw(Setting::ocamcqaiuaogsgck, false); $mkwywaswweooyqeq = $this->weysguygiseoukqw(Setting::akqiiuumacyksaas, false); if ($imuiukuiocoayoww && $mkwywaswweooyqeq) { $sqeykgyoooqysmca = Constants::ygoseweigiigswiu; } else { if ($mkwywaswweooyqeq) { $sqeykgyoooqysmca = Constants::ucoiewcoucauqwko; } else { $sqeykgyoooqysmca = Constants::qgmuskygocwmouos; } } return $sqeykgyoooqysmca; } public function iemckwasmaugwcwi() : bool { return (bool) $this->weysguygiseoukqw(Setting::iquacaoiugwceesk); } }
