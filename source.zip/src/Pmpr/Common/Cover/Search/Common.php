<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fcb2eda4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Search; use Pmpr\Common\Cover\Container; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class Common extends Container { const ecuwamcuymyycucq = Constants::ycusscwsoggmuweq . "\x5f\163\x65\141\162\143\150\x5f"; public function awwoqyciiocumkqq() { $ccamueccusigaaio = $this->caokeucsksukesyo()->giiecckwoyiawoyy()->yyqgamuwwakgciey(Constants::mgsccwumkcawaqcy, Constants::yyoaeaaaquyigiim); return $this->ocksiywmkyaqseou("\163\x65\x61\162\x63\x68\x5f\164\141\x72\x67\x65\x74", $ccamueccusigaaio); } public function sesseaeskwkeucks() : string { $imuiukuiocoayoww = $this->weysguygiseoukqw(Setting::ocamcqaiuaogsgck, false); $mkwywaswweooyqeq = $this->weysguygiseoukqw(Setting::akqiiuumacyksaas, false); if ($imuiukuiocoayoww && $mkwywaswweooyqeq) { $sqeykgyoooqysmca = Constants::ygoseweigiigswiu; } else { if ($mkwywaswweooyqeq) { $sqeykgyoooqysmca = Constants::ucoiewcoucauqwko; } else { $sqeykgyoooqysmca = Constants::qgmuskygocwmouos; } } return $sqeykgyoooqysmca; } public function iemckwasmaugwcwi() : bool { return (bool) $this->weysguygiseoukqw(Setting::iquacaoiugwceesk); } }
