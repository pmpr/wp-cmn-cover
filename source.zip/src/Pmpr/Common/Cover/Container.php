<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce633b36061             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function cskmiyuaesumyigg() { return Setting::eiwcuqigayigimak(Setting::gqgseikcqgoiuqeg, 0); } public function sqogiksomgaoegcy() { return $this->uwkmaywceaaaigwo()->iqsmaqoiukeasukw()->oiucukewkckkwiqc($this->cskmiyuaesumyigg()); } }
