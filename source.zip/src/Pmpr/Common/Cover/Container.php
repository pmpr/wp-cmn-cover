<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665c231f04cca             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function cskmiyuaesumyigg() { return Setting::eiwcuqigayigimak(Setting::gqgseikcqgoiuqeg, 0); } public function sqogiksomgaoegcy() { return $this->uwkmaywceaaaigwo()->iqsmaqoiukeasukw()->oiucukewkckkwiqc($this->cskmiyuaesumyigg()); } }
