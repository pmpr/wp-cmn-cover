<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1d166ebcf             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Account; class Account { }
