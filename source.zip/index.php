<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4ba10c294             |
    |_______________________________________|
*/
 use Pmpr\Common\Cover\Setting; use Pmpr\Common\Cover\Cover; Cover::symcgieuakksimmu(); if (!function_exists("\x67\145\164\137\x63\x6f\x76\145\x72\x5f\x73\145\164\164\151\x6e\x67")) { function get_cover_setting($uusmaiomayssaecw, $ggauoeuaesiymgee = null) { return Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq($uusmaiomayssaecw, $ggauoeuaesiymgee); } }
