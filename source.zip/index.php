<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6c83ea60             |
    |_______________________________________|
*/
 use Pmpr\Common\Cover\Setting\Setting; use Pmpr\Common\Cover\Cover; Cover::symcgieuakksimmu(); if (!function_exists("\x67\x65\164\x5f\x63\x6f\166\x65\x72\x5f\x73\x65\164\164\x69\x6e\x67")) { function get_cover_setting($uusmaiomayssaecw, $ggauoeuaesiymgee = null) { return Setting::eiwcuqigayigimak($uusmaiomayssaecw, $ggauoeuaesiymgee); } }
